"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAppState } from "@/context/StateContext";
import { MapPin, ChevronDown, Menu, X } from "lucide-react";

const NAV_LINKS = [
  { href: "/events",         label: "Events" },
  { href: "/directory",      label: "Directory" },
  { href: "/jobs",           label: "Jobs" },
  { href: "/community",      label: "Community" },
  { href: "/accommodations", label: "Accommodations" },
  { href: "/roommates",      label: "Roommates" },
  { href: "/seva",           label: "Seva AI" },
  { href: "/newcomers",      label: "Newcomers" },
];

export default function Nav() {
  const pathname  = usePathname();
  const { currentState, changeState } = useAppState();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-cream/95 backdrop-blur-xl border-b border-black/5 shadow-sm" : "bg-transparent"
      }`}
    >
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5 shrink-0">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-saffron to-gold flex items-center justify-center text-base">
            🏡
          </div>
          <span className="font-serif text-xl font-black tracking-tight">Apna</span>
        </Link>

        {/* Desktop Links */}
        <div className="hidden lg:flex items-center gap-0.5 overflow-x-auto">
          {NAV_LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={`px-3 py-2 rounded-lg text-[13px] font-semibold whitespace-nowrap transition-all ${
                pathname.startsWith(l.href)
                  ? "bg-saffron/10 text-saffron"
                  : "text-ink/60 hover:text-ink hover:bg-black/5"
              }`}
            >
              {l.label}
            </Link>
          ))}
        </div>

        {/* Right side */}
        <div className="flex items-center gap-2 shrink-0">
          {/* State selector pill */}
          <button
            onClick={changeState}
            className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-lg border border-black/8 bg-white/60 hover:bg-white transition-all text-[13px] font-bold text-ink/70 hover:text-ink"
          >
            <MapPin className="w-3.5 h-3.5 text-saffron" />
            {currentState ? currentState.code : "Pick State"}
            <ChevronDown className="w-3 h-3 opacity-50" />
          </button>

          <Link
            href="/dashboard"
            className="hidden sm:block px-4 py-2 rounded-lg text-[13px] font-bold border border-black/10 hover:bg-black/5 transition-all"
          >
            Dashboard
          </Link>

          <Link
            href="#"
            className="px-4 py-2 rounded-lg text-[13px] font-bold bg-gradient-to-r from-saffron to-gold text-white shadow-sm hover:opacity-90 transition-all"
          >
            Join Free
          </Link>

          {/* Mobile menu toggle */}
          <button
            className="lg:hidden p-2 rounded-lg hover:bg-black/5"
            onClick={() => setMobileOpen((v) => !v)}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-cream border-t border-black/5 px-4 py-4 flex flex-col gap-1">
          {NAV_LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              onClick={() => setMobileOpen(false)}
              className={`px-4 py-3 rounded-lg text-sm font-semibold transition-all ${
                pathname.startsWith(l.href) ? "bg-saffron/10 text-saffron" : "text-ink/70 hover:bg-black/5"
              }`}
            >
              {l.label}
            </Link>
          ))}
          <button
            onClick={() => { changeState(); setMobileOpen(false); }}
            className="flex items-center gap-2 px-4 py-3 rounded-lg text-sm font-semibold text-ink/60 hover:bg-black/5 mt-1"
          >
            <MapPin className="w-4 h-4 text-saffron" />
            {currentState ? `Change State (${currentState.code})` : "Choose Your State"}
          </button>
        </div>
      )}
    </nav>
  );
}
