"use client";
import { useAppState } from "@/context/StateContext";
import StatePicker from "@/components/StatePicker";

export default function StateGate({ children }) {
  const { showPicker, hydrated } = useAppState();

  // Don't render anything until localStorage is checked (prevents flash)
  if (!hydrated) {
    return (
      <div className="fixed inset-0 bg-ink flex items-center justify-center">
        <div className="text-cream/30 font-mono text-sm animate-pulse">Loading…</div>
      </div>
    );
  }

  return (
    <>
      {showPicker && <StatePicker />}
      <div className={showPicker ? "hidden" : ""}>{children}</div>
    </>
  );
}
