"use client";
import { useState } from "react";
import { STATES, TIER_LABELS } from "@/lib/states";
import { useAppState } from "@/context/StateContext";
import { Search } from "lucide-react";

export default function StatePicker() {
  const { selectState } = useAppState();
  const [query, setQuery]   = useState("");
  const [hovered, setHovered] = useState(null);

  const filtered = STATES.filter(
    (s) =>
      s.name.toLowerCase().includes(query.toLowerCase()) ||
      s.code.toLowerCase().includes(query.toLowerCase())
  );

  // Sort: mega first, then large, medium, small
  const sorted = [...filtered].sort((a, b) => {
    const order = { mega: 0, large: 1, medium: 2, small: 3 };
    return order[a.tier] - order[b.tier];
  });

  return (
    <div className="fixed inset-0 z-[200] flex flex-col bg-ink overflow-hidden">
      {/* Gradient overlays */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] rounded-full bg-saffron/10 blur-[120px]" />
        <div className="absolute bottom-0 right-0 w-[500px] h-[300px] rounded-full bg-gold/8 blur-[100px]" />
      </div>

      {/* Header */}
      <div className="relative z-10 flex flex-col items-center pt-14 pb-8 px-6 text-center">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-saffron to-gold flex items-center justify-center text-xl">
            🏡
          </div>
          <span className="font-serif text-2xl font-black text-cream">Apna</span>
        </div>

        <h1 className="font-serif text-4xl md:text-5xl font-black text-cream leading-tight mb-4">
          Welcome to{" "}
          <span className="text-saffron italic">आपना</span>
        </h1>
        <p className="text-cream/50 text-base md:text-lg max-w-lg leading-relaxed mb-8">
          India's community platform, built for every state in America. Choose your state to see events, businesses, jobs, and community near you.
        </p>

        {/* Search */}
        <div className="relative w-full max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-cream/40" />
          <input
            type="text"
            placeholder="Search your state..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            className="w-full pl-11 pr-4 py-3.5 bg-white/6 border border-white/10 rounded-xl text-cream placeholder-cream/30 text-sm outline-none focus:border-saffron/50 focus:bg-white/8 transition-all"
          />
        </div>
      </div>

      {/* States grid */}
      <div className="relative z-10 flex-1 overflow-y-auto px-6 pb-8">
        <div className="max-w-5xl mx-auto">
          {/* Tier groups */}
          {["mega", "large", "medium", "small"].map((tier) => {
            const group = sorted.filter((s) => s.tier === tier);
            if (!group.length) return null;
            const { label, color, bg } = TIER_LABELS[tier];
            return (
              <div key={tier} className="mb-8">
                <div className="flex items-center gap-2 mb-3">
                  <span
                    className="text-[10px] font-mono font-bold uppercase tracking-widest px-2.5 py-1 rounded"
                    style={{ color, background: `${color}20` }}
                  >
                    {label}
                  </span>
                  <div className="flex-1 h-px bg-white/5" />
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5">
                  {group.map((state) => (
                    <button
                      key={state.code}
                      onClick={() => selectState(state.code)}
                      onMouseEnter={() => setHovered(state.code)}
                      onMouseLeave={() => setHovered(null)}
                      className="relative flex flex-col items-start p-4 rounded-xl border transition-all duration-150 text-left group"
                      style={{
                        background: hovered === state.code ? `${color}12` : "rgba(255,255,255,0.03)",
                        borderColor: hovered === state.code ? `${color}40` : "rgba(255,255,255,0.06)",
                      }}
                    >
                      <div className="text-xl mb-2">{state.emoji}</div>
                      <div className="text-[11px] font-mono font-bold text-cream/40 mb-0.5">
                        {state.code}
                      </div>
                      <div className="text-sm font-bold text-cream/80 leading-tight">
                        {state.name}
                      </div>
                      <div className="text-[10px] text-cream/30 mt-1 font-mono">
                        {(state.population / 1000).toFixed(0)}K+ Indians
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            );
          })}

          {sorted.length === 0 && (
            <div className="text-center text-cream/30 py-12 font-mono text-sm">
              No states found for "{query}"
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
