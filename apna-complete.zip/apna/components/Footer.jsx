import Link from "next/link";

const COLS = [
  { title: "Platform",   links: [["Events", "/events"], ["Directory", "/directory"], ["Jobs", "/jobs"], ["Seva AI", "/seva"], ["Community", "/community"], ["Newcomers", "/newcomers"]] },
  { title: "Housing",    links: [["Find Accommodation", "/accommodations"], ["Find Roommate", "/roommates"], ["Post Accommodation", "/accommodations/post"], ["Post Roommate", "/roommates/post"], ["Newcomer Housing Guide", "/newcomers"]] },
  { title: "Business",   links: [["List Your Business", "/directory"], ["Premium Listing", "/dashboard"], ["Post a Job", "/jobs"], ["Event Ticketing", "/events"], ["Advertise on Apna", "/dashboard"]] },
];

export default function Footer() {
  return (
    <footer className="bg-ink text-cream/40 pt-14 pb-8">
      <div className="max-w-screen-xl mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-10 mb-12">
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-saffron to-gold flex items-center justify-center text-sm">🏡</div>
              <span className="font-serif text-xl font-black text-cream">Apna</span>
            </div>
            <p className="text-sm leading-relaxed mb-5">
              India's community platform for every state in America — events, directory, jobs, housing, roommates, AI concierge, and community forums. Free, forever.
            </p>
            <div className="flex gap-3">
              {["📘", "🐦", "📸", "▶️"].map((i) => (
                <div key={i} className="w-8 h-8 rounded-lg bg-white/6 flex items-center justify-center text-sm cursor-pointer hover:bg-white/12 transition-all">
                  {i}
                </div>
              ))}
            </div>
          </div>
          {COLS.map(({ title, links }) => (
            <div key={title}>
              <div className="text-xs font-bold uppercase tracking-widest text-cream/60 mb-4 font-mono">{title}</div>
              <ul className="flex flex-col gap-2.5">
                {links.map(([label, href]) => (
                  <li key={label}>
                    <Link href={href} className="text-sm hover:text-cream/80 transition-colors">{label}</Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t border-white/5 pt-6 flex flex-wrap justify-between gap-4 text-xs">
          <span>© 2026 Apna Technologies, Inc. · India's Community Platform for America</span>
          <div className="flex gap-5">
            {["Privacy", "Terms", "Contact"].map((l) => (
              <Link key={l} href="#" className="hover:text-cream/70 transition-colors">{l}</Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
