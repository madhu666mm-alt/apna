"use client";
import { createContext, useContext, useState, useEffect } from "react";
import { getStateByCode } from "@/lib/states";

const StateContext = createContext(null);

export function StateProvider({ children }) {
  const [stateCode, setStateCode]   = useState(null);  // e.g. "MI"
  const [showPicker, setShowPicker] = useState(false);
  const [hydrated, setHydrated]     = useState(false);

  // Load from localStorage once on mount
  useEffect(() => {
    const saved = localStorage.getItem("apna_state");
    if (saved) {
      setStateCode(saved);
      setShowPicker(false);
    } else {
      setShowPicker(true);  // First visit → show full-screen picker
    }
    setHydrated(true);
  }, []);

  const selectState = (code) => {
    setStateCode(code);
    localStorage.setItem("apna_state", code);
    setShowPicker(false);
  };

  const changeState = () => setShowPicker(true);

  const currentState = stateCode ? getStateByCode(stateCode) : null;

  return (
    <StateContext.Provider value={{ stateCode, currentState, selectState, changeState, showPicker, hydrated }}>
      {children}
    </StateContext.Provider>
  );
}

export const useAppState = () => {
  const ctx = useContext(StateContext);
  if (!ctx) throw new Error("useAppState must be used inside StateProvider");
  return ctx;
};
