"use client";
import { useState } from "react";
import Link from "next/link";
import { useAppState } from "@/context/StateContext";
import { EVENTS, byState } from "@/lib/data";
import { Search, MapPin, Filter } from "lucide-react";

const CATEGORIES = ["All", "Festival", "Concert", "Movie", "Workshop", "Wedding"];

export default function EventsPage() {
  const { currentState, stateCode } = useAppState();
  const [cat, setCat]       = useState("All");
  const [search, setSearch] = useState("");
  const [city, setCity]     = useState("All");
  const [showAll, setShowAll] = useState(false);

  const stateEvents = showAll ? EVENTS : byState(EVENTS, stateCode);
  const cities = ["All", ...new Set(stateEvents.map((e) => e.city))];

  const filtered = stateEvents.filter((e) =>
    (cat === "All" || e.category === cat) &&
    (city === "All" || e.city === city) &&
    (search === "" ||
      e.title.toLowerCase().includes(search.toLowerCase()) ||
      e.org.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="page-header">
        <div className="max-w-screen-xl mx-auto">
          <div className="page-header-tag">// Events</div>
          <h1 className="page-header-title">
            What's Happening in{" "}
            <span className="text-gold italic">{currentState?.name || "Your State"}</span>
          </h1>
          <p className="page-header-sub">Indian community events — festivals, concerts, workshops, movies, and more.</p>
          <div className="mt-6 flex gap-3 flex-wrap items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cream/30" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search events, artists, organizers..."
                className="w-full pl-10 pr-4 py-3 bg-white/8 border border-white/12 rounded-xl text-cream placeholder-cream/30 text-sm outline-none focus:border-gold/40 transition-all"
              />
            </div>
            <button
              onClick={() => setShowAll((v) => !v)}
              className="flex items-center gap-2 px-4 py-3 rounded-xl border border-white/12 bg-white/6 text-cream/70 text-sm font-semibold hover:bg-white/10 transition-all"
            >
              <MapPin className="w-4 h-4" />
              {showAll ? "All States" : currentState?.name || "All States"}
            </button>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="sticky top-16 z-30 bg-cream/95 backdrop-blur-xl border-b border-black/5 py-3 px-6">
        <div className="max-w-screen-xl mx-auto flex gap-3 flex-wrap items-center">
          <div className="flex gap-2 flex-wrap">
            {CATEGORIES.map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={`px-4 py-2 rounded-full text-sm font-bold border transition-all ${
                  cat === c
                    ? "bg-ink text-cream border-ink"
                    : "bg-transparent border-black/10 text-ink/60 hover:border-ink/30"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
          <select
            value={city}
            onChange={(e) => setCity(e.target.value)}
            className="ml-auto px-4 py-2 rounded-xl border border-black/10 text-sm font-semibold bg-white text-ink outline-none"
          >
            {cities.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
      </div>

      {/* Events grid */}
      <div className="max-w-screen-xl mx-auto px-6 py-10">
        <div className="text-xs font-mono text-ink/40 mb-6">{filtered.length} events found</div>
        {filtered.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filtered.map((ev) => (
              <Link key={ev.id} href={`/events/${ev.id}`} className="card card-hover block overflow-hidden">
                <div className="h-1.5" style={{ background: `linear-gradient(90deg,${ev.color},${ev.color}66)` }} />
                <div className="p-5">
                  <div className="flex gap-3 items-start mb-4">
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0" style={{ background: `${ev.color}15` }}>
                      {ev.emoji}
                    </div>
                    <div>
                      <div className="text-[10px] font-mono font-bold uppercase tracking-widest mb-1" style={{ color: ev.color }}>{ev.category}</div>
                      <div className="text-[15px] font-extrabold leading-tight">{ev.title}</div>
                      <div className="text-xs text-ink/40 mt-0.5">{ev.org}</div>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1.5 mb-4 text-xs text-ink/50">
                    <div>📅 {ev.date} · {ev.time}</div>
                    <div>📍 {ev.location}</div>
                  </div>
                  {ev.seats && (
                    <div className="mb-4">
                      <div className="flex justify-between text-[10px] font-mono text-ink/40 mb-1.5">
                        <span>Tickets</span><span>{ev.seats}/{ev.totalSeats} left</span>
                      </div>
                      <div className="h-1.5 bg-black/5 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${(ev.seats / ev.totalSeats) * 100}%`, background: ev.color }} />
                      </div>
                    </div>
                  )}
                  <div className="flex items-center justify-between pt-3 border-t border-black/5">
                    <span className="text-base font-black">{ev.price === 0 ? "Free" : `$${ev.price}`}</span>
                    <span className="text-xs font-bold text-white px-3 py-1.5 rounded-lg" style={{ background: ev.color }}>
                      {ev.price === 0 ? "RSVP" : "Get Tickets"} →
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 text-ink/30">
            <div className="text-5xl mb-4">📅</div>
            <div className="text-lg font-bold mb-2">No events found</div>
            <div className="text-sm">Try changing your filters or browsing all states.</div>
          </div>
        )}
      </div>
    </div>
  );
}
