"use client";
import { useState } from "react";
import Link from "next/link";
import { notFound } from "next/navigation";
import { EVENTS } from "@/lib/data";
import { ArrowLeft, MapPin, Clock, Users, Check } from "lucide-react";

export default function EventDetailPage({ params }) {
  const event = EVENTS.find((e) => e.id === params.id);
  if (!event) return notFound();

  const [tier, setTier]     = useState(0);
  const [qty, setQty]       = useState(1);
  const [bought, setBought] = useState(false);
  const [step, setStep]     = useState("select"); // select | confirm | done

  const selected = event.tiers[tier];
  const total    = selected.price * qty;

  return (
    <div className="min-h-screen pt-16">
      {/* Banner */}
      <div className="h-56 flex items-center justify-center relative" style={{ background: `linear-gradient(135deg, ${event.color}30, ${event.color}10)` }}>
        <div className="text-8xl">{event.emoji}</div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-cream pointer-events-none" />
      </div>

      <div className="max-w-5xl mx-auto px-6 pb-16">
        <Link href="/events" className="inline-flex items-center gap-2 text-sm text-ink/50 hover:text-ink mb-8 mt-4 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Events
        </Link>

        <div className="grid lg:grid-cols-[1fr_380px] gap-10 items-start">
          {/* LEFT */}
          <div>
            <span className="badge mb-3" style={{ background: `${event.color}15`, color: event.color }}>{event.category}</span>
            <h1 className="font-serif text-4xl font-black tracking-tight mb-3">{event.title}</h1>
            <div className="text-lg text-ink/50 font-semibold mb-8">Organized by {event.org}</div>

            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              {[
                [Clock, "Date & Time", `${event.date} · ${event.time}`],
                [MapPin, "Venue", event.location],
                [Users, "Category", event.category],
                [null, "Starting From", event.price === 0 ? "Free" : `$${event.price}`],
              ].map(([Icon, label, val]) => (
                <div key={label} className="card p-4">
                  {Icon && <Icon className="w-5 h-5 text-saffron mb-2" />}
                  <div className="label">{label}</div>
                  <div className="text-sm font-bold">{val}</div>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-extrabold mb-3">About This Event</h2>
            <p className="text-ink/60 leading-relaxed mb-8">{event.description}</p>

            {event.seats && (
              <div className="card p-5 mb-6">
                <div className="flex justify-between mb-3">
                  <span className="font-bold">Ticket Availability</span>
                  <span className="font-mono text-sm font-bold" style={{ color: event.color }}>{event.seats}/{event.totalSeats} remaining</span>
                </div>
                <div className="h-2.5 bg-black/5 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all" style={{ width: `${(event.seats / event.totalSeats) * 100}%`, background: event.color }} />
                </div>
              </div>
            )}
          </div>

          {/* TICKET BOX */}
          <div className="sticky top-20">
            <div className="card shadow-xl overflow-hidden">
              <div className="p-5 border-b border-black/5" style={{ background: `${event.color}08` }}>
                <div className="label">Get Tickets</div>
                <div className="font-serif text-xl font-black">{event.title}</div>
              </div>

              {step === "done" ? (
                <div className="p-8 text-center">
                  <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check className="w-8 h-8 text-green-600" />
                  </div>
                  <div className="font-serif text-2xl font-black mb-2">You're going! 🎉</div>
                  <div className="text-sm text-ink/50 mb-6 leading-relaxed">Your ticket is confirmed. A QR code has been sent to your email.</div>
                  <div className="rounded-xl p-4 mb-6 text-center" style={{ background: `${event.color}10`, border: `1px solid ${event.color}30` }}>
                    <div className="text-[10px] font-mono font-bold uppercase tracking-widest mb-2" style={{ color: event.color }}>QR TICKET</div>
                    <div className="text-4xl tracking-widest font-mono text-ink/20">█▄▀▄█▄▀</div>
                    <div className="text-[10px] text-ink/30 mt-2 font-mono">APNA-{Math.random().toString(36).slice(2, 8).toUpperCase()}</div>
                  </div>
                  <button onClick={() => setStep("select")} className="btn-outline w-full justify-center">Buy More Tickets</button>
                </div>
              ) : (
                <div className="p-5">
                  {/* Tier selection */}
                  <div className="mb-5">
                    <div className="label">Ticket Type</div>
                    {event.tiers.map((t, i) => (
                      <div
                        key={i}
                        onClick={() => setTier(i)}
                        className="p-4 rounded-xl border-2 mb-2 cursor-pointer transition-all"
                        style={{
                          borderColor: tier === i ? event.color : "rgba(0,0,0,0.08)",
                          background:  tier === i ? `${event.color}08` : "transparent",
                        }}
                      >
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="text-sm font-bold">{t.name}</div>
                            <div className="text-xs text-ink/40">{t.available} available</div>
                          </div>
                          <div className="text-lg font-black" style={{ color: tier === i ? event.color : undefined }}>
                            {t.price === 0 ? "Free" : `$${t.price}`}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Quantity */}
                  {selected.price > 0 && (
                    <div className="mb-5">
                      <div className="label">Quantity</div>
                      <div className="flex items-center gap-4">
                        <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="w-9 h-9 rounded-lg border border-black/10 flex items-center justify-center text-lg font-bold hover:bg-black/5 transition-all">−</button>
                        <span className="text-xl font-black w-8 text-center">{qty}</span>
                        <button onClick={() => setQty((q) => Math.min(10, q + 1))} className="w-9 h-9 rounded-lg border border-black/10 flex items-center justify-center text-lg font-bold hover:bg-black/5 transition-all">+</button>
                      </div>
                    </div>
                  )}

                  {/* Total */}
                  {selected.price > 0 && (
                    <div className="flex justify-between items-center p-4 bg-cream-dark rounded-xl mb-4">
                      <span className="text-sm font-bold">Total</span>
                      <span className="text-xl font-black">${total}</span>
                    </div>
                  )}

                  <button
                    onClick={() => setStep("done")}
                    className="w-full py-4 rounded-xl text-white font-extrabold text-base transition-all hover:opacity-90"
                    style={{ background: `linear-gradient(135deg, ${event.color}, ${event.color}BB)` }}
                  >
                    {selected.price === 0 ? "RSVP — Free" : `Pay $${total} →`}
                  </button>
                  <div className="text-center text-xs text-ink/30 mt-3">Secure checkout · QR ticket via email · No hidden fees</div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
