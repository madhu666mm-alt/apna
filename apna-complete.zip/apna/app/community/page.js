"use client";
import Link from "next/link";
import { CIRCLES } from "@/lib/data";

export default function CommunityPage() {
  return (
    <div className="min-h-screen">
      <div className="page-header">
        <div className="max-w-screen-xl mx-auto">
          <div className="page-header-tag">// Community</div>
          <h1 className="page-header-title">Community Circles</h1>
          <p className="page-header-sub">Your people, your conversations. Across all 50 states.</p>
        </div>
      </div>
      <div className="max-w-screen-xl mx-auto px-6 py-10">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {CIRCLES.map((c) => (
            <Link key={c.id} href={`/community/${c.id}`} className="card card-hover block p-6 relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1 rounded-t-2xl" style={{ background: `linear-gradient(90deg, ${c.color}, ${c.color}66)` }} />
              <div className="text-4xl mb-4">{c.emoji}</div>
              <div className="text-[15px] font-extrabold mb-2">{c.name}</div>
              <div className="text-xs text-ink/50 leading-relaxed mb-4">{c.description}</div>
              <div className="flex flex-wrap gap-1.5 mb-4">
                {c.tags.map((t) => <span key={t} className="badge bg-black/5 text-ink/50">{t}</span>)}
              </div>
              <div className="flex justify-between items-center border-t border-black/5 pt-3">
                <div className="flex gap-4 text-xs text-ink/40">
                  <span><strong className="text-ink">{c.members.toLocaleString()}</strong> members</span>
                  <span><strong className="text-ink">{c.posts.toLocaleString()}</strong> posts</span>
                </div>
                <button className="text-xs font-bold px-3 py-1.5 rounded-lg" style={{ background: `${c.color}15`, color: c.color }}>Join</button>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
