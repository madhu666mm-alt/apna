"use client";
import { useState } from "react";
import Link from "next/link";
import { CIRCLES } from "@/lib/data";
import { ArrowLeft, ThumbsUp, MessageSquare, Share2 } from "lucide-react";

const SAMPLE_POSTS = [
  { id: 1, author: "Rohan S.", avatar: "RS", time: "2 hours ago", title: "Best Indian grocery near Troy MI?", body: "Just moved to Troy from Hyderabad. Looking for a good Indian grocery store — specifically need fresh curry leaves and kokum. Any recommendations?", likes: 12, replies: 8, pinned: true },
  { id: 2, author: "Meera K.", avatar: "MK", time: "5 hours ago", title: "Great deal on curry leaves at Patel Brothers Canton", body: "FYI - Patel Brothers in Canton just got fresh curry leaves in stock. Also they have fresh methi and drumsticks! Stock up before the weekend crowd.", likes: 34, replies: 3, pinned: false },
  { id: 3, author: "Arjun P.", avatar: "AP", time: "1 day ago", title: "Anyone been to the new restaurant on Rochester Rd?", body: "Went to 'Namaste Kitchen' that opened last month near Rochester Rd, Troy. The food is amazing — great butter chicken and the garlic naan is soft. Definitely recommend!", likes: 28, replies: 15, pinned: false },
];

export default function CircleDetailPage({ params }) {
  const circle = CIRCLES.find((c) => c.id === params.id);
  const [posts, setPosts] = useState(SAMPLE_POSTS);
  const [newPost, setNewPost] = useState("");
  const [newTitle, setNewTitle] = useState("");
  const [likes, setLikes] = useState({});
  const [joined, setJoined] = useState(false);

  if (!circle) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center"><Link href="/community" className="btn-fill">Back to Community</Link></div>
    </div>
  );

  const toggleLike = (id) => setLikes((l) => ({ ...l, [id]: !l[id] }));

  const addPost = () => {
    if (!newTitle.trim()) return;
    const post = { id: Date.now(), author: "You", avatar: "YO", time: "Just now", title: newTitle.trim(), body: newPost.trim(), likes: 0, replies: 0, pinned: false };
    setPosts((p) => [post, ...p]);
    setNewTitle(""); setNewPost("");
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="page-header" style={{ background: `linear-gradient(135deg, #0F0A00, ${circle.color}25)` }}>
        <div className="max-w-3xl mx-auto">
          <Link href="/community" className="inline-flex items-center gap-2 text-cream/40 hover:text-cream/70 mb-6 text-sm transition-colors">
            <ArrowLeft className="w-4 h-4" /> Community
          </Link>
          <div className="flex items-start gap-5 mb-6">
            <div className="text-5xl">{circle.emoji}</div>
            <div>
              <h1 className="page-header-title mb-1">{circle.name}</h1>
              <p className="text-cream/50 text-sm leading-relaxed mb-3">{circle.description}</p>
              <div className="flex items-center gap-4 text-xs text-cream/30 font-mono">
                <span><strong className="text-cream/70">{circle.members.toLocaleString()}</strong> members</span>
                <span><strong className="text-cream/70">{circle.posts.toLocaleString()}</strong> posts</span>
              </div>
            </div>
          </div>
          <button onClick={() => setJoined((v) => !v)} className={`px-5 py-2.5 rounded-xl text-sm font-bold transition-all ${joined ? "bg-white/10 text-cream/60 border border-white/15" : "bg-gradient-to-r from-saffron to-gold text-white"}`}>
            {joined ? "✓ Joined" : "Join Circle →"}
          </button>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-6 py-8">
        {/* Post form */}
        <div className="card p-5 mb-6 shadow-sm">
          <div className="text-sm font-bold mb-3">Share something with the community</div>
          <input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder="Post title..." className="input mb-3 text-sm" />
          <textarea value={newPost} onChange={(e) => setNewPost(e.target.value)} rows={3} placeholder="Share your question, recommendation, or update..." className="input resize-none text-sm mb-3" />
          <button onClick={addPost} disabled={!newTitle.trim()} className="btn-fill disabled:opacity-50">Post →</button>
        </div>

        {/* Posts */}
        <div className="space-y-4">
          {posts.map((p) => (
            <div key={p.id} className="card p-5">
              {p.pinned && <div className="badge bg-gold/10 text-gold mb-3">📌 Pinned Post</div>}
              <div className="flex items-center gap-3 mb-3">
                <div className="w-9 h-9 rounded-xl font-bold flex items-center justify-center text-sm text-white shrink-0" style={{ background: circle.color }}>{p.avatar}</div>
                <div>
                  <div className="text-sm font-extrabold">{p.author}</div>
                  <div className="text-[10px] text-ink/30 font-mono">{p.time}</div>
                </div>
              </div>
              <h3 className="font-extrabold mb-2">{p.title}</h3>
              <p className="text-sm text-ink/60 leading-relaxed mb-4">{p.body}</p>
              <div className="flex gap-4 pt-3 border-t border-black/5">
                <button onClick={() => toggleLike(p.id)} className={`flex items-center gap-1.5 text-xs font-semibold transition-colors ${likes[p.id] ? "text-saffron" : "text-ink/40 hover:text-ink"}`}>
                  <ThumbsUp className="w-3.5 h-3.5" />{p.likes + (likes[p.id] ? 1 : 0)}
                </button>
                <button className="flex items-center gap-1.5 text-xs font-semibold text-ink/40 hover:text-ink transition-colors">
                  <MessageSquare className="w-3.5 h-3.5" />{p.replies} replies
                </button>
                <button className="flex items-center gap-1.5 text-xs font-semibold text-ink/40 hover:text-ink transition-colors ml-auto">
                  <Share2 className="w-3.5 h-3.5" /> Share
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
