"use client";
import { useState } from "react";
import { useAppState } from "@/context/StateContext";
import Link from "next/link";

const STEPS = [
  { id: 1, emoji: "🪪", title: "Social Security Number (SSN)", time: "Week 1", color: "#E8420A",
    content: "Your SSN is the most important document in America — you need it for everything.\n\n**Where to go:** Local Social Security Administration (SSA) office. Find the nearest one at ssa.gov/locator.\n\n**What to bring:**\n• Valid passport\n• US visa (H1B, F1, OPT, etc.)\n• I-94 arrival record (print from cbp.dhs.gov/i94)\n• Employment Authorization or offer letter (H1B)\n\n**Timeline:** Apply within the first week. Card arrives by mail in 7–14 business days.\n\n**Pro tip:** Many SSA offices are busy — go early (before 9am) on Tuesday or Wednesday to avoid long waits.",
    links: [["SSA Office Locator", "https://ssa.gov/locator"], ["Print I-94", "https://cbp.dhs.gov/i94"]] },

  { id: 2, emoji: "🏦", title: "Open a Bank Account", time: "Week 1", color: "#2563EB",
    content: "You need a bank account immediately for payroll, rent, and daily expenses.\n\n**Best options for new immigrants:**\n• **Chase** — Widespread branches, great app, easy H1B/F1 opening\n• **Bank of America** — 4,000+ branches nationally\n• **HDFC Bank USA** — Ideal for NRIs, connects to India account\n• **Axis Bank USA** — Great for remittances to India\n\n**What to bring:**\n• Passport + visa\n• SSN (if received) or ITIN / visa number\n• Initial deposit ($25–$100 typically)\n• Proof of address (rental agreement or utility bill)\n\n**Without SSN:** Chase and BoA will often open accounts with just your passport and visa. Ask for the international banking specialist.\n\n**Pro tip:** Open a checking AND savings account on the same day. Set up direct deposit with your employer immediately.",
    links: [["Chase International", "https://chase.com"], ["HDFC Bank USA", "https://hdfcbankusa.com"]] },

  { id: 3, emoji: "📱", title: "SIM Card & Phone Plan", time: "Day 1–3", color: "#059669",
    content: "Get a US number immediately — you'll need it for job calls, apartment hunting, and bank verification.\n\n**Best prepaid options (no credit check):**\n• **T-Mobile Prepaid** — $40/mo unlimited, excellent coverage\n• **Mint Mobile** — $15/mo on T-Mobile network (buy online)\n• **Google Fi** — Works in India too, great for travelers\n• **Visible** (Verizon) — $25/mo unlimited\n\n**Best postpaid (after 1 month):**\n• Verizon or AT&T with your SSN and first paycheck\n\n**Indian community tip:** Many people buy an international SIM at the airport and switch to prepaid within the first week. T-Mobile's prepaid plan is the most popular among Indian newcomers.\n\n**eSIM option:** Buy a US eSIM on Airalo before you even land. Works immediately on arrival.",
    links: [["Mint Mobile", "https://mintmobile.com"], ["Airalo eSIM", "https://airalo.com"]] },

  { id: 4, emoji: "🏠", title: "Find Accommodation", time: "Before Arrival", color: "#7C3AED",
    content: "Housing is your biggest challenge as a newcomer — plan ahead.\n\n**Short-term options (first month):**\n• **Extended Stay America** — Weekly rates, kitchen included, most immigrant-friendly\n• **Indian community roommates** — Check Apna's Roommates section\n• **Furnished Finder** — Month-to-month furnished apartments\n\n**Long-term (1-year lease):**\n• Most landlords require: SSN, 2 pay stubs, 3x monthly rent income\n• **Without credit history:** Offer 2–3 months security deposit, or a co-signer\n• **Credit-check alternatives:** NOVA Credit translates Indian credit to US equivalent\n\n**Indian community areas to look:**\n• Michigan: Canton, Troy, Novi, Farmington Hills, Sterling Heights\n• California: Fremont, Santa Clara, Sunnyvale, Milpitas\n• NJ: Edison, Piscataway, Princeton, Parsippany\n• Texas: Sugar Land, Plano, Frisco, Carrollton\n\n**Pro tip:** Always check Apna's Accommodations section for community-vetted listings with Indian landlords who understand your situation.",
    links: [["Apna Accommodations", "/accommodations"], ["NOVA Credit", "https://novacredit.com"]] },

  { id: 5, emoji: "🚗", title: "Driver's License & Car", time: "Month 1", color: "#D97706",
    content: "You can drive on your international license for 30–90 days (varies by state). Get a US license ASAP.\n\n**To get a driver's license:**\n1. Visit your state DMV (schedule online to avoid long waits)\n2. Pass written knowledge test (study your state's driver handbook)\n3. Pass road/driving test\n4. Get learner's permit first if needed\n\n**What to bring to DMV:**\n• Passport + visa\n• I-94 arrival record\n• SSN card (or SSN receipt)\n• 2 proofs of state residence (bank statement + utility bill)\n\n**Car buying without credit history:**\n• Start with a used car from a dealer (easier financing)\n• Credit unions (Navy Federal, State Employees) are more H1B-friendly\n• Bring a large down payment (20–30%) to offset credit risk\n• Some dealers specialize in financing for immigrants\n\n**Insurance:** Geico and State Farm are most common. Expect $100–$200/month for new drivers.",
    links: [["Find Your DMV", "https://dmv.org"], ["Geico Insurance", "https://geico.com"]] },

  { id: 6, emoji: "🏥", title: "Health Insurance", time: "Day 1", color: "#DC2626",
    content: "Health insurance is critical and can be very expensive without employer coverage.\n\n**If your employer provides insurance:**\n• Enroll on your first day or during the open enrollment window\n• Choose a plan: PPO (more flexible) vs HMO (cheaper, requires referrals)\n• Add dental and vision if offered — very affordable through employer\n\n**If you need to buy your own:**\n• Healthcare.gov marketplace plans (open enrollment Nov–Jan)\n• Special enrollment period if you just arrived: 60 days from arrival\n• Medicaid if income is low (check your state's eligibility)\n\n**Indian-community doctor tip:**\n• Ask your community for referrals to Indian-American doctors\n• They often understand cultural dietary habits and health patterns\n• Most major Indian areas have Indian physicians: cardiologists, GPs, OBGYNs\n\n**Cost context:** A typical PPO employer plan costs $100–200/month for individual, $400–600 for family. Emergency ER visits without insurance can cost $5,000–$50,000.",
    links: [["Healthcare.gov", "https://healthcare.gov"]] },

  { id: 7, emoji: "💳", title: "Build Credit Score", time: "Month 1–6", color: "#0891B2",
    content: "Your credit score determines everything in America — apartment approval, car loans, credit cards, even some jobs.\n\n**Start building credit immediately:**\n1. **Secured credit card** — Deposit $200–500, get a card with that limit. Discover Secured and Capital One Secured are best.\n2. **Credit card with no credit history** — Chase Freedom Student (if F1), or Deserve EDU\n3. **Authorized user** — Ask a trusted friend/colleague to add you to their card\n4. **NOVA Credit** — Converts Indian CIBIL score to US credit equivalent\n\n**The golden rules of credit:**\n• Pay the FULL balance every month (never carry a balance)\n• Keep usage below 30% of your limit\n• Never miss a payment\n• Don't apply for too many cards at once\n\n**Timeline to good credit:**\n• 3 months: First score appears (~680)\n• 6 months: Score improves (~720)\n• 12 months: Good credit (~750+)\n\n**Pro tip:** Set up autopay for the minimum payment immediately. Then pay the full balance manually each month.",
    links: [["NOVA Credit", "https://novacredit.com"], ["Discover Secured", "https://discover.com"]] },

  { id: 8, emoji: "🙏", title: "Find Your Community", time: "Week 1", color: "#BE185D",
    content: "The most underrated newcomer step: find your people.\n\n**Temple & religious communities:**\n• BAPS Swaminarayan Mandir — Gujarati community hub, events every weekend\n• ISKCON — Open to all, vegetarian prasad, community events\n• Venkateswara (Balaji) temples — Telugu/South Indian community\n• Chinmaya Mission — Cultural and spiritual events, classes\n\n**Professional networks:**\n• TiE (The Indus Entrepreneurs) — Business networking\n• SANA (South Asian Network Association) — General community\n• Your state's Indian association (e.g., Michigan India Association)\n\n**Online communities:**\n• Apna Community Circles — Right here! Join the Newcomers Hub\n• Local Facebook groups: 'Indians in Detroit', 'Desi in Bay Area', etc.\n• WhatsApp groups via temple communities\n\n**Why it matters:** Your first job referral, your apartment lead, your immigration lawyer, your doctor — in 80% of cases, it comes from your community network.\n\n**Pro tip:** Attend the first event at your local temple the first weekend you arrive. Even if you're not religious, the social network is invaluable.",
    links: [["Apna Newcomers Circle", "/community"], ["Apna Accommodations", "/accommodations"]] },
];

export default function NewcomersPage() {
  const { currentState } = useAppState();
  const [activeStep, setActiveStep] = useState(1);
  const step = STEPS.find((s) => s.id === activeStep);

  return (
    <div className="min-h-screen">
      <div className="page-header">
        <div className="max-w-screen-xl mx-auto">
          <div className="page-header-tag">// Newcomers</div>
          <h1 className="page-header-title">
            Your First 30 Days in{" "}
            <span className="text-gold italic">{currentState?.name || "America"}</span>
          </h1>
          <p className="page-header-sub">The 8-step playbook every Indian newcomer needs. Straight from the community, in plain language.</p>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-6 py-10">
        <div className="grid lg:grid-cols-[320px_1fr] gap-8 items-start">
          {/* Step list */}
          <div className="sticky top-20 space-y-2">
            {STEPS.map((s) => (
              <button key={s.id} onClick={() => setActiveStep(s.id)} className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all ${activeStep === s.id ? "border-transparent shadow-lg" : "border-black/5 bg-white hover:border-black/10"}`}
                style={activeStep === s.id ? { background: `${s.color}08`, borderColor: `${s.color}30` } : {}}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0" style={{ background: `${s.color}15` }}>{s.emoji}</div>
                <div>
                  <div className="text-[10px] font-mono font-bold uppercase tracking-widest mb-0.5" style={{ color: activeStep === s.id ? s.color : "#9CA3AF" }}>{s.time}</div>
                  <div className="text-[13px] font-extrabold leading-tight">{s.title}</div>
                </div>
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="card p-8 shadow-lg">
            <div className="flex items-start gap-5 mb-8">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shrink-0" style={{ background: `${step.color}15` }}>{step.emoji}</div>
              <div>
                <div className="text-[10px] font-mono font-bold uppercase tracking-widest mb-2" style={{ color: step.color }}>{step.time}</div>
                <h2 className="font-serif text-3xl font-black">Step {step.id}: {step.title}</h2>
              </div>
            </div>

            <div className="prose prose-sm max-w-none mb-8">
              {step.content.split("\n\n").map((para, i) => (
                <p key={i} className="text-sm text-ink/70 leading-relaxed mb-4" dangerouslySetInnerHTML={{
                  __html: para.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/^• (.+)$/gm, "<li>$1</li>")
                }} />
              ))}
            </div>

            {step.links.length > 0 && (
              <div className="flex flex-wrap gap-3">
                {step.links.map(([label, href]) => (
                  href.startsWith("/") ? (
                    <Link key={label} href={href} className="btn-fill text-sm">{label} →</Link>
                  ) : (
                    <a key={label} href={href} target="_blank" rel="noopener noreferrer" className="btn-outline text-sm">{label} ↗</a>
                  )
                ))}
              </div>
            )}

            <div className="flex justify-between mt-10 pt-6 border-t border-black/5">
              <button onClick={() => setActiveStep((s) => Math.max(1, s - 1))} disabled={activeStep === 1} className="btn-outline disabled:opacity-30">← Previous</button>
              <span className="text-xs font-mono text-ink/30 self-center">{activeStep} / {STEPS.length}</span>
              <button onClick={() => setActiveStep((s) => Math.min(STEPS.length, s + 1))} disabled={activeStep === STEPS.length} className="btn-fill disabled:opacity-50">Next →</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
