"use client";
import { useState, useRef, useEffect } from "react";
import { useAppState } from "@/context/StateContext";
import { Send, Languages } from "lucide-react";

const LANGS    = ["English", "हिंदी", "ગુજરાતી", "తెలుగు", "தமிழ்", "ਪੰਜਾਬੀ", "বাংলা"];
const PROMPTS  = [
  ["🎪", "Events",    "What Indian events are happening this weekend near me?"],
  ["🍽️", "Food",     "Best South Indian restaurant near my area?"],
  ["📋", "H1B",      "What documents do I need for H1B renewal in 2026?"],
  ["🛬", "Newcomer", "I just arrived. What should I do in the first week?"],
  ["💼", "Jobs",     "Which Michigan companies sponsor H1B visas?"],
  ["🏠", "Housing",  "Best neighborhoods for Indian families near Detroit?"],
  ["🎓", "OPT",      "OPT to H1B cap-gap — what are the rules?"],
  ["📞", "Remit",    "Best way to send money to India right now?"],
];

export default function SevaPage() {
  const { currentState, stateCode } = useAppState();
  const [msgs, setMsgs]     = useState([{
    role: "assistant",
    content: `Namaste! 🙏 I'm **Seva**, your personal Apna assistant.\n\nI can help you with:\n• 🎪 Events in ${currentState?.name || "your state"}\n• 🍽️ Restaurant & business recommendations\n• 📋 H1B, OPT, Green Card guidance\n• 🛬 Newcomer checklist and advice\n• 💼 Job opportunities\n• 🗣️ I speak Hindi, Gujarati, Telugu, Tamil, Punjabi, Bengali & English!\n\nWhat can I help you with today?`
  }]);
  const [input, setInput]   = useState("");
  const [loading, setLoading] = useState(false);
  const [lang, setLang]     = useState("English");
  const endRef              = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput("");
    setMsgs((p) => [...p, { role: "user", content: userMsg }]);
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...msgs, { role: "user", content: userMsg }].map((m) => ({
            role:    m.role,
            content: m.content,
          })),
          stateCode,
          stateName: currentState?.name,
        }),
      });
      const data = await res.json();
      setMsgs((p) => [...p, { role: "assistant", content: data.content || "Sorry, try again!" }]);
    } catch {
      setMsgs((p) => [...p, { role: "assistant", content: "Connection issue — please try again 🙏" }]);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen pt-16 bg-ink flex flex-col" style={{ height: "100dvh" }}>
      {/* Header */}
      <div className="bg-white/4 border-b border-white/6 px-4 py-3 flex items-center gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-saffron to-gold flex items-center justify-center text-xl">🙏</div>
          <div>
            <div className="text-cream font-extrabold text-sm">Seva AI</div>
            <div className="flex items-center gap-1.5 text-[10px] text-green-400 font-mono font-bold">
              <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              Live · Powered by Claude
              {currentState && ` · ${currentState.name}`}
            </div>
          </div>
        </div>

        {/* Language selector */}
        <div className="flex items-center gap-2 ml-auto flex-wrap">
          <Languages className="w-4 h-4 text-cream/30" />
          {LANGS.map((l) => (
            <button key={l} onClick={() => setLang(l)} className={`text-[12px] px-2.5 py-1.5 rounded-lg border font-semibold transition-all ${lang === l ? "border-gold/50 bg-gold/15 text-gold" : "border-white/10 text-cream/40 hover:border-white/20"}`}>{l}</button>
          ))}
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden max-w-screen-xl mx-auto w-full">
        {/* Sidebar prompts */}
        <div className="hidden md:flex flex-col w-56 border-r border-white/6 p-4 gap-2 overflow-y-auto shrink-0">
          <div className="text-[10px] font-mono font-bold uppercase tracking-widest text-cream/25 mb-2">Quick Prompts</div>
          {PROMPTS.map(([em, label, q]) => (
            <button key={label} onClick={() => setInput(q)} className="flex gap-2 items-start text-left p-3 rounded-xl border border-white/5 hover:border-white/12 hover:bg-white/4 transition-all group">
              <span className="text-base shrink-0">{em}</span>
              <div>
                <div className="text-[10px] font-mono font-bold text-cream/25 uppercase tracking-wide mb-0.5">{label}</div>
                <div className="text-[12px] text-cream/50 leading-snug group-hover:text-cream/70 transition-colors">{q}</div>
              </div>
            </button>
          ))}
        </div>

        {/* Chat area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
            {msgs.map((m, i) => (
              <div key={i} className={`flex gap-3 items-start ${m.role === "user" ? "flex-row-reverse" : ""}`}>
                {m.role === "assistant" && (
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-saffron to-gold flex items-center justify-center text-sm shrink-0">🙏</div>
                )}
                <div className={`max-w-[75%] px-4 py-3 rounded-2xl text-[14px] leading-relaxed whitespace-pre-wrap ${
                  m.role === "user"
                    ? "bg-gradient-to-br from-saffron to-gold text-white rounded-tr-sm font-medium"
                    : "bg-white/8 text-cream/85 rounded-tl-sm"
                }`}>
                  {m.content}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex gap-3 items-start">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-saffron to-gold flex items-center justify-center text-sm">🙏</div>
                <div className="px-4 py-3 rounded-2xl bg-white/8 rounded-tl-sm">
                  <div className="flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <div key={i} className="w-2 h-2 rounded-full bg-cream/30 animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                    ))}
                  </div>
                </div>
              </div>
            )}
            <div ref={endRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-white/6">
            <div className="flex gap-3 items-center">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && send()}
                placeholder={`Ask Seva in ${lang}...`}
                className="flex-1 px-4 py-3 bg-white/8 border border-white/10 rounded-xl text-cream placeholder-cream/25 text-sm outline-none focus:border-gold/40 transition-all"
              />
              <button
                onClick={send}
                disabled={loading || !input.trim()}
                className="w-11 h-11 rounded-xl bg-gradient-to-br from-saffron to-gold flex items-center justify-center text-white hover:opacity-90 transition-all disabled:opacity-40 shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
