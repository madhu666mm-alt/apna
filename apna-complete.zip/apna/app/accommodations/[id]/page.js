"use client";
import { useState } from "react";
import Link from "next/link";
import { ACCOMMODATIONS } from "@/lib/data";
import { ArrowLeft, MapPin, Home, Bed, Bath, Calendar, Mail, Phone, Check } from "lucide-react";

export default function AccomDetailPage({ params }) {
  const a = ACCOMMODATIONS.find((x) => x.id === params.id);
  const [contacted, setContacted] = useState(false);
  const [msg, setMsg] = useState("");

  if (!a) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center"><div className="text-4xl mb-4">🏠</div><div className="font-bold">Listing not found</div><Link href="/accommodations" className="btn-fill mt-4 inline-flex">Back to Listings</Link></div>
    </div>
  );

  return (
    <div className="min-h-screen pt-16">
      <div className="h-48 bg-gradient-to-br from-saffron/15 to-gold/10 flex items-center justify-center text-7xl">🏠</div>

      <div className="max-w-5xl mx-auto px-6 pb-16">
        <Link href="/accommodations" className="inline-flex items-center gap-2 text-sm text-ink/50 hover:text-ink mt-4 mb-6 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Listings
        </Link>

        <div className="grid lg:grid-cols-[1fr_340px] gap-10 items-start">
          <div>
            <div className="flex gap-2 flex-wrap mb-3">
              <span className="badge bg-saffron/10 text-saffron">{a.type}</span>
              {a.furnished && <span className="badge bg-blue-50 text-blue-700">Furnished</span>}
              {a.petsOk && <span className="badge bg-green-50 text-green-700">Pets OK</span>}
            </div>
            <h1 className="font-serif text-3xl md:text-4xl font-black tracking-tight mb-3">{a.title}</h1>
            <div className="flex items-center gap-2 text-ink/50 text-sm mb-8">
              <MapPin className="w-4 h-4 text-saffron" />{a.address}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
              {[
                [Bed, "Bedrooms", a.bedrooms === 0 ? "Studio" : a.bedrooms],
                [Bath, "Bathrooms", a.bathrooms],
                [Home, "Size", `${a.sqft} sqft`],
                [Calendar, "Available", a.availableFrom],
              ].map(([Icon, label, val]) => (
                <div key={label} className="card p-4 text-center">
                  <Icon className="w-5 h-5 text-saffron mx-auto mb-2" />
                  <div className="label text-center">{label}</div>
                  <div className="text-sm font-extrabold">{val}</div>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-extrabold mb-3">About This Listing</h2>
            <p className="text-ink/60 leading-relaxed mb-8">{a.description}</p>

            <h2 className="text-xl font-extrabold mb-4">Amenities</h2>
            <div className="flex flex-wrap gap-2 mb-8">
              {a.amenities.map((am) => (
                <div key={am} className="flex items-center gap-2 px-4 py-2 bg-green-50 rounded-xl text-sm font-semibold text-green-700">
                  <Check className="w-3.5 h-3.5" />{am}
                </div>
              ))}
            </div>

            <div className="card p-5 bg-saffron/5 border-saffron/20">
              <div className="text-sm text-ink/60 leading-relaxed">
                <strong>⚠️ Safety tip:</strong> Never send money before viewing the property. Meet in a public place or video call first. Verify the listing by calling the number provided. Apna is not responsible for individual listings.
              </div>
            </div>
          </div>

          {/* Contact sidebar */}
          <div className="sticky top-20 space-y-4">
            <div className="card p-6 shadow-lg">
              <div className="text-3xl font-black text-saffron mb-0.5">${a.price.toLocaleString()}<span className="text-base font-semibold text-ink/40">/month</span></div>
              <div className="text-xs text-ink/40 mb-6 font-mono">Available from {a.availableFrom}</div>

              {contacted ? (
                <div className="text-center py-4">
                  <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-3"><Check className="w-6 h-6 text-green-600" /></div>
                  <div className="font-bold text-sm mb-1">Message Sent!</div>
                  <div className="text-xs text-ink/40">The owner will reply to your email within 24 hours.</div>
                </div>
              ) : (
                <>
                  <div className="mb-3">
                    <label className="label">Your Message</label>
                    <textarea value={msg} onChange={(e) => setMsg(e.target.value)} rows={3} placeholder="Hi, I'm interested in this listing. When can I schedule a viewing?" className="input resize-none text-sm" />
                  </div>
                  <button onClick={() => setContacted(true)} className="btn-fill w-full justify-center mb-3">Contact Owner →</button>
                  <div className="flex flex-col gap-2">
                    <a href={`mailto:${a.contact}`} className="flex items-center gap-2 text-sm text-ink/60 hover:text-ink transition-colors">
                      <Mail className="w-4 h-4" />{a.contact}
                    </a>
                  </div>
                </>
              )}
            </div>

            <div className="card p-5">
              <div className="text-sm font-extrabold mb-3">Posted By</div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-saffron/10 flex items-center justify-center text-lg">👤</div>
                <div>
                  <div className="text-sm font-bold">{a.postedBy}</div>
                  <div className="text-xs text-ink/40">Posted {a.postedAt}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
