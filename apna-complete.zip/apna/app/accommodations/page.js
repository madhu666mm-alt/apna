"use client";
import { useState } from "react";
import Link from "next/link";
import { useAppState } from "@/context/StateContext";
import { ACCOMMODATIONS, byState } from "@/lib/data";
import { Search, Plus, Home, DollarSign, MapPin, Bed, Bath, X, Check } from "lucide-react";

const TYPES = ["All", "Apartment", "House", "Room", "Studio", "Condo"];

function AccomCard({ a }) {
  return (
    <Link href={`/accommodations/${a.id}`} className="card card-hover block overflow-hidden">
      <div className="h-1.5 bg-gradient-to-r from-saffron to-gold" />
      <div className="p-5">
        <div className="flex gap-2 mb-2 flex-wrap">
          <span className="badge bg-saffron/10 text-saffron">{a.type}</span>
          {a.furnished && <span className="badge bg-blue-50 text-blue-700">Furnished</span>}
          {a.petsOk && <span className="badge bg-green-50 text-green-700">Pets OK</span>}
        </div>
        <h3 className="text-[15px] font-extrabold mb-1 leading-tight">{a.title}</h3>
        <div className="flex items-center gap-1 text-xs text-ink/50 mb-4">
          <MapPin className="w-3 h-3" />{a.city}, {a.state}
        </div>
        <div className="grid grid-cols-3 gap-3 mb-4">
          {[
            [Bed, a.bedrooms === 0 ? "Studio" : `${a.bedrooms} BR`],
            [Bath, `${a.bathrooms} BA`],
            [Home, `${a.sqft} sqft`],
          ].map(([Icon, val]) => (
            <div key={val} className="flex items-center gap-1.5 text-xs text-ink/60 font-semibold">
              <Icon className="w-3.5 h-3.5" />{val}
            </div>
          ))}
        </div>
        <p className="text-xs text-ink/50 leading-relaxed mb-4 line-clamp-2">{a.description}</p>
        <div className="flex items-center justify-between pt-3 border-t border-black/5">
          <div>
            <span className="text-xl font-black text-saffron">${a.price.toLocaleString()}</span>
            <span className="text-xs text-ink/40">/mo</span>
          </div>
          <div className="text-right">
            <div className="text-xs text-ink/40 mb-0.5">Available</div>
            <div className="text-xs font-bold">{a.availableFrom}</div>
          </div>
        </div>
        <div className="mt-2 text-[10px] text-ink/30 font-mono">Posted by {a.postedBy} · {a.postedAt}</div>
      </div>
    </Link>
  );
}

function PostModal({ onClose }) {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    title: "", type: "Apartment", city: "", price: "", bedrooms: "1",
    bathrooms: "1", sqft: "", availableFrom: "", furnished: false,
    petsOk: false, description: "", name: "", email: "", phone: "",
  });
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  if (submitted) {
    return (
      <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
        <div className="bg-white rounded-2xl p-10 max-w-md w-full text-center" onClick={(e) => e.stopPropagation()}>
          <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4"><Check className="w-8 h-8 text-green-600" /></div>
          <h3 className="font-serif text-2xl font-black mb-2">Listing Posted! 🎉</h3>
          <p className="text-ink/50 text-sm mb-6">Your accommodation listing has been submitted for review. It will be live within 24 hours.</p>
          <button onClick={onClose} className="btn-fill w-full justify-center">Done</button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
      <div className="bg-white w-full sm:max-w-2xl sm:rounded-2xl overflow-hidden max-h-[95vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-black/5 sticky top-0 bg-white z-10">
          <h2 className="font-serif text-xl font-black">Post Accommodation</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-black/5 flex items-center justify-center hover:bg-black/10 transition-all"><X className="w-4 h-4" /></button>
        </div>
        <div className="p-6 space-y-5">
          <div>
            <label className="label">Listing Title *</label>
            <input value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="e.g. Spacious 2BR near Ford HQ, Dearborn" className="input" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Type *</label>
              <select value={form.type} onChange={(e) => set("type", e.target.value)} className="input">
                {["Apartment", "House", "Room", "Studio", "Condo"].map((t) => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Monthly Rent ($) *</label>
              <input type="number" value={form.price} onChange={(e) => set("price", e.target.value)} placeholder="1500" className="input" />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="label">Bedrooms</label>
              <select value={form.bedrooms} onChange={(e) => set("bedrooms", e.target.value)} className="input">
                {["0 (Studio)", "1", "2", "3", "4", "5+"].map((v) => <option key={v}>{v}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Bathrooms</label>
              <select value={form.bathrooms} onChange={(e) => set("bathrooms", e.target.value)} className="input">
                {["1", "1.5", "2", "2.5", "3+"].map((v) => <option key={v}>{v}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Sq Ft (approx)</label>
              <input type="number" value={form.sqft} onChange={(e) => set("sqft", e.target.value)} placeholder="900" className="input" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">City *</label>
              <input value={form.city} onChange={(e) => set("city", e.target.value)} placeholder="e.g. Canton, Troy, Novi" className="input" />
            </div>
            <div>
              <label className="label">Available From *</label>
              <input type="date" value={form.availableFrom} onChange={(e) => set("availableFrom", e.target.value)} className="input" />
            </div>
          </div>
          <div className="flex gap-6">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.furnished} onChange={(e) => set("furnished", e.target.checked)} className="w-4 h-4 accent-saffron" />
              <span className="text-sm font-semibold">Furnished</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.petsOk} onChange={(e) => set("petsOk", e.target.checked)} className="w-4 h-4 accent-saffron" />
              <span className="text-sm font-semibold">Pets OK</span>
            </label>
          </div>
          <div>
            <label className="label">Description *</label>
            <textarea value={form.description} onChange={(e) => set("description", e.target.value)} rows={4} placeholder="Describe the property — nearby landmarks, ideal tenant, neighborhood vibe..." className="input resize-none" />
          </div>
          <div className="border-t border-black/5 pt-5">
            <div className="text-sm font-bold mb-4">Your Contact Info</div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Name *</label>
                <input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Your name" className="input" />
              </div>
              <div>
                <label className="label">Email *</label>
                <input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="your@email.com" className="input" />
              </div>
            </div>
            <div className="mt-4">
              <label className="label">Phone (Optional)</label>
              <input value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="(xxx) xxx-xxxx" className="input" />
            </div>
          </div>
          <button onClick={() => setSubmitted(true)} className="btn-fill w-full justify-center text-base py-4">Post Listing →</button>
          <p className="text-xs text-ink/30 text-center">Free to post. All listings reviewed within 24 hours.</p>
        </div>
      </div>
    </div>
  );
}

export default function AccommodationsPage() {
  const { stateCode, currentState } = useAppState();
  const [type, setType]     = useState("All");
  const [search, setSearch] = useState("");
  const [showAll, setShowAll]  = useState(false);
  const [maxPrice, setMaxPrice] = useState("");
  const [showPost, setShowPost] = useState(false);

  const pool = showAll ? ACCOMMODATIONS : byState(ACCOMMODATIONS, stateCode);

  const filtered = pool.filter((a) =>
    (type === "All" || a.type === type) &&
    (maxPrice === "" || a.price <= Number(maxPrice)) &&
    (search === "" ||
      a.title.toLowerCase().includes(search.toLowerCase()) ||
      a.city.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="min-h-screen">
      {showPost && <PostModal onClose={() => setShowPost(false)} />}

      {/* Header */}
      <div className="page-header">
        <div className="max-w-screen-xl mx-auto">
          <div className="page-header-tag">// Accommodations</div>
          <h1 className="page-header-title">
            Find a Place in{" "}
            <span className="text-gold italic">{currentState?.name || "Your State"}</span>
          </h1>
          <p className="page-header-sub">
            Community-verified housing listings — apartments, houses, rooms near Indian neighborhoods, temples, and tech corridors.
          </p>
          <div className="mt-6 flex gap-3 flex-wrap items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cream/30" />
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by title, city..." className="w-full pl-10 pr-4 py-3 bg-white/8 border border-white/12 rounded-xl text-cream placeholder-cream/30 text-sm outline-none focus:border-gold/40 transition-all" />
            </div>
            <button onClick={() => setShowPost(true)} className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-saffron to-gold text-white font-bold text-sm hover:opacity-90 transition-all">
              <Plus className="w-4 h-4" /> Post Listing
            </button>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="sticky top-16 z-30 bg-cream/95 backdrop-blur-xl border-b border-black/5 py-3 px-6">
        <div className="max-w-screen-xl mx-auto flex gap-3 flex-wrap items-center">
          <div className="flex gap-2 flex-wrap">
            {TYPES.map((t) => (
              <button key={t} onClick={() => setType(t)} className={`px-4 py-2 rounded-full text-sm font-bold border transition-all ${type === t ? "bg-ink text-cream border-ink" : "bg-transparent border-black/10 text-ink/60 hover:border-ink/30"}`}>{t}</button>
            ))}
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <DollarSign className="w-4 h-4 text-ink/40" />
            <input type="number" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} placeholder="Max rent/mo" className="w-32 px-3 py-2 rounded-xl border border-black/10 text-sm outline-none" />
            <button onClick={() => setShowAll((v) => !v)} className="px-3 py-2 rounded-xl border border-black/10 text-sm font-semibold text-ink/60 hover:bg-black/5 transition-all">
              <MapPin className="w-3.5 h-3.5 inline mr-1" />{showAll ? "All States" : currentState?.code || "All"}
            </button>
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="max-w-screen-xl mx-auto px-6 py-10">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div className="text-xs font-mono text-ink/40">{filtered.length} listings found</div>
          <button onClick={() => setShowPost(true)} className="btn-fill gap-2 text-sm">
            <Plus className="w-4 h-4" /> Post Your Accommodation
          </button>
        </div>

        {filtered.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map((a) => <AccomCard key={a.id} a={a} />)}
          </div>
        ) : (
          <div className="text-center py-20 text-ink/30">
            <div className="text-5xl mb-4">🏠</div>
            <div className="text-lg font-bold mb-2">No listings found</div>
            <div className="text-sm mb-6">Be the first to post an accommodation in {currentState?.name}!</div>
            <button onClick={() => setShowPost(true)} className="btn-fill inline-flex">Post Listing →</button>
          </div>
        )}
      </div>
    </div>
  );
}
