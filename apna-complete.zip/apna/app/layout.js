import "./globals.css";
import { StateProvider } from "@/context/StateContext";
import Nav            from "@/components/Nav";
import Footer         from "@/components/Footer";
import StatePicker    from "@/components/StatePicker";
import StateGate      from "@/components/StateGate";

export const metadata = {
  title:       "Apna — India's Community Platform for America",
  description: "Events, businesses, jobs, accommodations, roommates, AI concierge and community forums for Indian-Americans in every US state.",
  keywords:    "Indian community, Indian events, desi, NRI, Michigan Indians, H1B jobs",
  openGraph: {
    title:       "Apna — India's Community Platform",
    description: "Your state. Your people. Your home away from home.",
    type:        "website",
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-cream text-ink antialiased">
        <StateProvider>
          <StateGate>
            <Nav />
            <main className="min-h-screen">{children}</main>
            <Footer />
          </StateGate>
        </StateProvider>
      </body>
    </html>
  );
}
