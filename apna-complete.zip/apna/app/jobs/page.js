"use client";
import { useState } from "react";
import { useAppState } from "@/context/StateContext";
import { JOBS, byState } from "@/lib/data";
import { Search, MapPin, Briefcase } from "lucide-react";

const VISAS = ["All", "H1B Sponsor", "OPT / CPT OK", "J1 / H1B", "No Sponsor"];

export default function JobsPage() {
  const { currentState, stateCode } = useAppState();
  const [visa, setVisa]     = useState("All");
  const [search, setSearch] = useState("");
  const [showAll, setShowAll] = useState(false);

  const pool = showAll ? JOBS : byState(JOBS, stateCode);
  const filtered = pool.filter((j) =>
    (visa === "All" || j.visa === visa) &&
    (search === "" ||
      j.title.toLowerCase().includes(search.toLowerCase()) ||
      j.company.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="min-h-screen">
      <div className="page-header">
        <div className="max-w-screen-xl mx-auto">
          <div className="page-header-tag">// Jobs</div>
          <h1 className="page-header-title">Jobs with <span className="text-green-400">Visa Filters</span></h1>
          <p className="page-header-sub">Every job tagged by H1B, OPT, Green Card sponsorship. Finally.</p>
          <div className="mt-6 flex gap-3 flex-wrap items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cream/30" />
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Job title, company, skills..." className="w-full pl-10 pr-4 py-3 bg-white/8 border border-white/12 rounded-xl text-cream placeholder-cream/30 text-sm outline-none focus:border-gold/40" />
            </div>
            <button onClick={() => setShowAll((v) => !v)} className="flex items-center gap-2 px-4 py-3 rounded-xl border border-white/12 bg-white/6 text-cream/70 text-sm font-semibold hover:bg-white/10 transition-all">
              <MapPin className="w-4 h-4" />{showAll ? "All States" : currentState?.name || "All"}
            </button>
          </div>
        </div>
      </div>

      <div className="sticky top-16 z-30 bg-cream/95 backdrop-blur-xl border-b border-black/5 py-3 px-6">
        <div className="max-w-screen-xl mx-auto flex gap-2 flex-wrap items-center">
          <span className="text-xs font-bold text-ink/40 mr-1">Visa:</span>
          {VISAS.map((v) => (
            <button key={v} onClick={() => setVisa(v)} className={`px-4 py-2 rounded-full text-sm font-bold border transition-all ${visa === v ? "bg-green-600 text-white border-green-600" : "bg-transparent border-black/10 text-ink/60 hover:border-black/30"}`}>{v}</button>
          ))}
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-6 py-10">
        <div className="text-xs font-mono text-ink/40 mb-6">{filtered.length} jobs found</div>
        <div className="flex flex-col gap-3 mb-10">
          {filtered.map((j) => (
            <div key={j.id} className="card card-hover p-5 flex flex-wrap items-center gap-5 justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-cream-dark rounded-xl flex items-center justify-center text-2xl shrink-0">{j.emoji}</div>
                <div>
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="text-[15px] font-extrabold">{j.title}</span>
                    {j.hot && <span className="badge bg-red-50 text-red-600">🔥 Hot</span>}
                  </div>
                  <div className="text-sm text-ink/50 font-semibold mb-2">{j.company} · {j.location}</div>
                  <div className="flex gap-2 flex-wrap">
                    <span className="badge bg-green-50 text-green-700">{j.visa}</span>
                    <span className="badge bg-black/5 text-ink/60">{j.type}</span>
                    {j.tags.map((t) => <span key={t} className="badge bg-blue-50 text-blue-700">{t}</span>)}
                    <span className="text-[10px] font-mono text-ink/30">{j.posted}</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-lg font-black mb-2">{j.salary}</div>
                <button className="btn-fill text-xs px-4 py-2">Apply →</button>
              </div>
            </div>
          ))}
        </div>

        <div className="card p-6 bg-saffron/5 border-saffron/15 flex flex-wrap items-center gap-5">
          <div className="text-3xl">💼</div>
          <div className="flex-1 min-w-0">
            <div className="font-extrabold mb-1">Are you an employer? Post a job.</div>
            <div className="text-sm text-ink/50">Reach Indian-American talent across all 50 states. Tag your H1B sponsorship status.</div>
          </div>
          <button className="btn-fill shrink-0">Post a Job — $149 →</button>
        </div>
      </div>
    </div>
  );
}
