"use client";
import { useState } from "react";
import Link from "next/link";
import { useAppState } from "@/context/StateContext";
import { ROOMMATES, byState } from "@/lib/data";
import { Search, Plus, MapPin, DollarSign, X, Check, Filter } from "lucide-react";

function RoommateCard({ r }) {
  const initials = r.name.split(" ").map((n) => n[0]).join("").slice(0, 2);
  return (
    <Link href={`/roommates/${r.id}`} className="card card-hover block p-6">
      <div className="flex gap-4 items-start mb-4">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-saffron/20 to-gold/20 flex items-center justify-center text-xl font-black text-saffron shrink-0">
          {initials}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <div className="text-[15px] font-extrabold">{r.name}</div>
            <span className="badge bg-black/5 text-ink/60">{r.age}y · {r.gender}</span>
          </div>
          <div className="text-sm text-ink/50 truncate">{r.profession}</div>
          <div className="text-xs text-ink/40 mt-0.5">Looking for: <span className="font-bold text-ink/60">{r.lookingFor}</span></div>
        </div>
      </div>

      <p className="text-xs text-ink/50 leading-relaxed mb-4 line-clamp-2">{r.description}</p>

      <div className="flex flex-wrap gap-1.5 mb-4">
        {r.habits.map((h) => (
          <span key={h} className="badge bg-saffron/8 text-saffron/80">{h}</span>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-3 text-xs mb-3">
        <div><span className="text-ink/40">Budget:</span> <span className="font-bold text-saffron">${r.budget}/mo</span></div>
        <div><span className="text-ink/40">Move in:</span> <span className="font-bold">{r.moveInDate}</span></div>
      </div>

      <div className="text-xs text-ink/40 flex items-center gap-1">
        <MapPin className="w-3 h-3" />{r.cities.join(" · ")}
      </div>

      <div className="mt-3 pt-3 border-t border-black/5 flex items-center justify-between">
        <div className="flex gap-1">
          {r.languages.map((l) => <span key={l} className="badge bg-blue-50 text-blue-600">{l}</span>)}
        </div>
        <span className="text-[10px] font-mono text-ink/30">{r.postedAt}</span>
      </div>
    </Link>
  );
}

function PostModal({ onClose }) {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: "", age: "", gender: "Male", profession: "", lookingFor: "Any",
    budget: "", cities: "", moveInDate: "", hasPlace: false,
    description: "", vegetarian: false, nonSmoker: false, languages: "", email: "",
  });
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  if (submitted) {
    return (
      <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
        <div className="bg-white rounded-2xl p-10 max-w-md w-full text-center" onClick={(e) => e.stopPropagation()}>
          <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4"><Check className="w-8 h-8 text-green-600" /></div>
          <h3 className="font-serif text-2xl font-black mb-2">Profile Posted! 🤝</h3>
          <p className="text-ink/50 text-sm mb-6">Your roommate profile is under review and will be live within 24 hours.</p>
          <button onClick={onClose} className="btn-fill w-full justify-center">Done</button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
      <div className="bg-white w-full sm:max-w-2xl sm:rounded-2xl overflow-hidden max-h-[95vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-black/5 sticky top-0 bg-white z-10">
          <h2 className="font-serif text-xl font-black">Post Roommate Profile</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-black/5 flex items-center justify-center hover:bg-black/10 transition-all"><X className="w-4 h-4" /></button>
        </div>
        <div className="p-6 space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Your Name *</label>
              <input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="First name" className="input" />
            </div>
            <div>
              <label className="label">Age *</label>
              <input type="number" value={form.age} onChange={(e) => set("age", e.target.value)} placeholder="26" className="input" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Gender *</label>
              <select value={form.gender} onChange={(e) => set("gender", e.target.value)} className="input">
                {["Male", "Female", "Non-binary", "Couple"].map((g) => <option key={g}>{g}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Looking for Roommate</label>
              <select value={form.lookingFor} onChange={(e) => set("lookingFor", e.target.value)} className="input">
                {["Any", "Male Only", "Female Only", "Indian Preferred"].map((g) => <option key={g}>{g}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="label">Profession / Occupation *</label>
            <input value={form.profession} onChange={(e) => set("profession", e.target.value)} placeholder="e.g. Software Engineer at Google, PhD Student at U of M" className="input" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Max Budget ($/mo) *</label>
              <input type="number" value={form.budget} onChange={(e) => set("budget", e.target.value)} placeholder="1000" className="input" />
            </div>
            <div>
              <label className="label">Move-in Date *</label>
              <input type="date" value={form.moveInDate} onChange={(e) => set("moveInDate", e.target.value)} className="input" />
            </div>
          </div>
          <div>
            <label className="label">Preferred Cities (comma-separated)</label>
            <input value={form.cities} onChange={(e) => set("cities", e.target.value)} placeholder="Troy, Novi, Canton" className="input" />
          </div>
          <div>
            <label className="label">Languages Spoken</label>
            <input value={form.languages} onChange={(e) => set("languages", e.target.value)} placeholder="English, Hindi, Gujarati" className="input" />
          </div>
          <div className="flex gap-6 flex-wrap">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.vegetarian} onChange={(e) => set("vegetarian", e.target.checked)} className="w-4 h-4 accent-saffron" />
              <span className="text-sm font-semibold">Vegetarian</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.nonSmoker} onChange={(e) => set("nonSmoker", e.target.checked)} className="w-4 h-4 accent-saffron" />
              <span className="text-sm font-semibold">Non-Smoker</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.hasPlace} onChange={(e) => set("hasPlace", e.target.checked)} className="w-4 h-4 accent-saffron" />
              <span className="text-sm font-semibold">I have a place (looking for tenant)</span>
            </label>
          </div>
          <div>
            <label className="label">About You *</label>
            <textarea value={form.description} onChange={(e) => set("description", e.target.value)} rows={4} placeholder="Tell potential roommates about yourself — lifestyle, work schedule, hobbies, what you're looking for..." className="input resize-none" />
          </div>
          <div>
            <label className="label">Contact Email *</label>
            <input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="your@email.com" className="input" />
          </div>
          <button onClick={() => setSubmitted(true)} className="btn-fill w-full justify-center text-base py-4">Post Roommate Profile →</button>
          <p className="text-xs text-ink/30 text-center">Free to post. Your email is only shared when someone contacts you.</p>
        </div>
      </div>
    </div>
  );
}

export default function RoommatesPage() {
  const { stateCode, currentState } = useAppState();
  const [search, setSearch]   = useState("");
  const [gender, setGender]   = useState("All");
  const [showAll, setShowAll] = useState(false);
  const [showPost, setShowPost] = useState(false);
  const [maxBudget, setMaxBudget] = useState("");

  const pool = showAll ? ROOMMATES : byState(ROOMMATES, stateCode);

  const filtered = pool.filter((r) =>
    (gender === "All" || r.gender === gender || r.lookingFor === gender) &&
    (maxBudget === "" || r.budget <= Number(maxBudget)) &&
    (search === "" ||
      r.name.toLowerCase().includes(search.toLowerCase()) ||
      r.profession.toLowerCase().includes(search.toLowerCase()) ||
      r.cities.some((c) => c.toLowerCase().includes(search.toLowerCase())))
  );

  return (
    <div className="min-h-screen">
      {showPost && <PostModal onClose={() => setShowPost(false)} />}

      {/* Header */}
      <div className="page-header">
        <div className="max-w-screen-xl mx-auto">
          <div className="page-header-tag">// Roommates</div>
          <h1 className="page-header-title">
            Find a Roommate in{" "}
            <span className="text-gold italic">{currentState?.name || "Your State"}</span>
          </h1>
          <p className="page-header-sub">
            Indian professionals and students looking for roommates. Filter by diet, habits, gender, budget, and city.
          </p>
          <div className="mt-6 flex gap-3 flex-wrap items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cream/30" />
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name, profession, city..." className="w-full pl-10 pr-4 py-3 bg-white/8 border border-white/12 rounded-xl text-cream placeholder-cream/30 text-sm outline-none focus:border-gold/40 transition-all" />
            </div>
            <button onClick={() => setShowPost(true)} className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-saffron to-gold text-white font-bold text-sm hover:opacity-90 transition-all">
              <Plus className="w-4 h-4" /> Post Profile
            </button>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="sticky top-16 z-30 bg-cream/95 backdrop-blur-xl border-b border-black/5 py-3 px-6">
        <div className="max-w-screen-xl mx-auto flex gap-3 flex-wrap items-center">
          <div className="flex gap-2 flex-wrap">
            {["All", "Male", "Female", "Couple"].map((g) => (
              <button key={g} onClick={() => setGender(g)} className={`px-4 py-2 rounded-full text-sm font-bold border transition-all ${gender === g ? "bg-ink text-cream border-ink" : "bg-transparent border-black/10 text-ink/60 hover:border-ink/30"}`}>{g}</button>
            ))}
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <DollarSign className="w-4 h-4 text-ink/40" />
            <input type="number" value={maxBudget} onChange={(e) => setMaxBudget(e.target.value)} placeholder="Max budget" className="w-28 px-3 py-2 rounded-xl border border-black/10 text-sm outline-none" />
            <button onClick={() => setShowAll((v) => !v)} className="px-3 py-2 rounded-xl border border-black/10 text-sm font-semibold text-ink/60 hover:bg-black/5 transition-all">
              <MapPin className="w-3.5 h-3.5 inline mr-1" />{showAll ? "All States" : currentState?.code || "All"}
            </button>
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="max-w-screen-xl mx-auto px-6 py-10">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div className="text-xs font-mono text-ink/40">{filtered.length} profiles found</div>
          <button onClick={() => setShowPost(true)} className="btn-fill gap-2 text-sm">
            <Plus className="w-4 h-4" /> Post Your Roommate Profile
          </button>
        </div>

        {filtered.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filtered.map((r) => <RoommateCard key={r.id} r={r} />)}
          </div>
        ) : (
          <div className="text-center py-20 text-ink/30">
            <div className="text-5xl mb-4">🤝</div>
            <div className="text-lg font-bold mb-2">No profiles found</div>
            <div className="text-sm mb-6">Be the first to post in {currentState?.name}!</div>
            <button onClick={() => setShowPost(true)} className="btn-fill inline-flex">Post Your Profile →</button>
          </div>
        )}
      </div>
    </div>
  );
}
