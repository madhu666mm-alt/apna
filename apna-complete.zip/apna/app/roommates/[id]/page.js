"use client";
import { useState } from "react";
import Link from "next/link";
import { ROOMMATES } from "@/lib/data";
import { ArrowLeft, MapPin, DollarSign, Calendar, Mail, MessageSquare, Check } from "lucide-react";

export default function RoommateDetailPage({ params }) {
  const r = ROOMMATES.find((x) => x.id === params.id);
  const [contacted, setContacted] = useState(false);
  const [msg, setMsg] = useState("");

  if (!r) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <div className="text-4xl mb-4">🤝</div>
        <div className="font-bold">Profile not found</div>
        <Link href="/roommates" className="btn-fill mt-4 inline-flex">Back to Roommates</Link>
      </div>
    </div>
  );

  const initials = r.name.split(" ").map((n) => n[0]).join("").slice(0, 2);

  return (
    <div className="min-h-screen pt-16 bg-cream">
      <div className="h-40 bg-gradient-to-br from-blue-50 to-saffron/10 flex items-center justify-center">
        <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-saffron/20 to-gold/20 flex items-center justify-center text-4xl font-black text-saffron shadow-lg">
          {initials}
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 pb-16">
        <Link href="/roommates" className="inline-flex items-center gap-2 text-sm text-ink/50 hover:text-ink mt-4 mb-6 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Roommates
        </Link>

        <div className="grid lg:grid-cols-[1fr_320px] gap-8 items-start">
          <div>
            <div className="flex gap-2 mb-3 flex-wrap">
              <span className="badge bg-saffron/10 text-saffron">{r.gender}</span>
              <span className="badge bg-black/5 text-ink/60">{r.age} years old</span>
              {r.hasPlace && <span className="badge bg-blue-50 text-blue-700">Has a Place</span>}
            </div>
            <h1 className="font-serif text-3xl md:text-4xl font-black tracking-tight mb-2">{r.name}</h1>
            <div className="text-base font-semibold text-ink/50 mb-2">{r.profession}</div>
            <div className="flex items-center gap-2 text-sm text-ink/40 mb-8">
              <MapPin className="w-4 h-4 text-saffron" />
              Prefers: {r.cities.join(" · ")}
            </div>

            <div className="grid sm:grid-cols-3 gap-4 mb-8">
              <div className="card p-4 text-center">
                <DollarSign className="w-5 h-5 text-saffron mx-auto mb-2" />
                <div className="label text-center">Max Budget</div>
                <div className="text-lg font-extrabold">${r.budget}<span className="text-xs text-ink/40">/mo</span></div>
              </div>
              <div className="card p-4 text-center">
                <Calendar className="w-5 h-5 text-saffron mx-auto mb-2" />
                <div className="label text-center">Move-in</div>
                <div className="text-sm font-extrabold">{r.moveInDate}</div>
              </div>
              <div className="card p-4 text-center">
                <MessageSquare className="w-5 h-5 text-saffron mx-auto mb-2" />
                <div className="label text-center">Looking for</div>
                <div className="text-sm font-extrabold">{r.lookingFor}</div>
              </div>
            </div>

            <h2 className="text-xl font-extrabold mb-3">About</h2>
            <p className="text-ink/60 leading-relaxed mb-8">{r.description}</p>

            <h2 className="text-xl font-extrabold mb-4">Lifestyle & Habits</h2>
            <div className="flex flex-wrap gap-2 mb-8">
              {r.habits.map((h) => (
                <div key={h} className="flex items-center gap-2 px-4 py-2 bg-saffron/8 rounded-xl text-sm font-semibold text-saffron/80">
                  <Check className="w-3.5 h-3.5" />{h}
                </div>
              ))}
            </div>

            <h2 className="text-xl font-extrabold mb-4">Languages</h2>
            <div className="flex flex-wrap gap-2 mb-8">
              {r.languages.map((l) => (
                <span key={l} className="badge bg-blue-50 text-blue-700 text-sm px-3 py-1.5">{l}</span>
              ))}
            </div>

            <div className="card p-5 bg-saffron/5 border-saffron/20">
              <div className="text-sm text-ink/60 leading-relaxed">
                <strong>⚠️ Safety tip:</strong> Always video call before meeting. Meet in public for the first time. Never share personal financial info upfront. Trust your instincts.
              </div>
            </div>
          </div>

          {/* Contact */}
          <div className="sticky top-20">
            <div className="card p-6 shadow-lg">
              <div className="font-serif text-xl font-black mb-1">Connect with {r.name.split(" ")[0]}</div>
              <div className="text-xs text-ink/40 mb-6 font-mono">Posted {r.postedAt}</div>

              {contacted ? (
                <div className="text-center py-6">
                  <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-3"><Check className="w-6 h-6 text-green-600" /></div>
                  <div className="font-bold text-sm mb-1">Message Sent!</div>
                  <div className="text-xs text-ink/40 leading-relaxed">They will reply to your email within 24 hours. Good luck finding your roommate!</div>
                </div>
              ) : (
                <>
                  <div className="mb-3">
                    <label className="label">Your Message</label>
                    <textarea value={msg} onChange={(e) => setMsg(e.target.value)} rows={4} placeholder={`Hi ${r.name.split(" ")[0]}, I saw your profile and I think we'd be great roommates! I'm a...`} className="input resize-none text-sm" />
                  </div>
                  <button onClick={() => setContacted(true)} className="btn-fill w-full justify-center mb-4">Send Message →</button>
                  <div className="flex items-center gap-2 text-sm text-ink/50 hover:text-ink transition-colors">
                    <Mail className="w-4 h-4 text-saffron" />
                    <a href={`mailto:${r.contact}`} className="truncate">{r.contact}</a>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
