"use client";
import { useState } from "react";
import Link from "next/link";
import { useAppState } from "@/context/StateContext";
import { BUSINESSES, byState } from "@/lib/data";
import { Search, Star, MapPin } from "lucide-react";

const CATS = ["All", "Restaurant", "Grocery", "Salon", "Legal", "Real Estate", "Sweets", "Medical"];

export default function DirectoryPage() {
  const { currentState, stateCode } = useAppState();
  const [cat, setCat]       = useState("All");
  const [search, setSearch] = useState("");
  const [showAll, setShowAll] = useState(false);

  const pool = showAll ? BUSINESSES : byState(BUSINESSES, stateCode);
  const filtered = pool.filter((b) =>
    (cat === "All" || b.category === cat) &&
    (search === "" ||
      b.name.toLowerCase().includes(search.toLowerCase()) ||
      b.tags.some((t) => t.toLowerCase().includes(search.toLowerCase())))
  );

  return (
    <div className="min-h-screen">
      <div className="page-header">
        <div className="max-w-screen-xl mx-auto">
          <div className="page-header-tag">// Directory</div>
          <h1 className="page-header-title">Indian Business Directory</h1>
          <p className="page-header-sub">Restaurants, groceries, lawyers, doctors — all with real community reviews.</p>
          <div className="mt-6 flex gap-3 flex-wrap items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cream/30" />
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search businesses, cuisine, services..." className="w-full pl-10 pr-4 py-3 bg-white/8 border border-white/12 rounded-xl text-cream placeholder-cream/30 text-sm outline-none focus:border-gold/40" />
            </div>
            <button onClick={() => setShowAll((v) => !v)} className="flex items-center gap-2 px-4 py-3 rounded-xl border border-white/12 bg-white/6 text-cream/70 text-sm font-semibold hover:bg-white/10 transition-all">
              <MapPin className="w-4 h-4" />{showAll ? "All States" : currentState?.name || "All"}
            </button>
          </div>
        </div>
      </div>

      <div className="sticky top-16 z-30 bg-cream/95 backdrop-blur-xl border-b border-black/5 py-3 px-6">
        <div className="max-w-screen-xl mx-auto flex gap-2 flex-wrap">
          {CATS.map((c) => (
            <button key={c} onClick={() => setCat(c)} className={`px-4 py-2 rounded-full text-sm font-bold border transition-all ${cat === c ? "bg-ink text-cream border-ink" : "bg-transparent border-black/10 text-ink/60 hover:border-black/30"}`}>{c}</button>
          ))}
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-6 py-10">
        <div className="text-xs font-mono text-ink/40 mb-6">{filtered.length} businesses</div>
        {filtered.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((b) => (
              <Link key={b.id} href={`/directory/${b.id}`} className="card card-hover block p-5">
                <div className="flex gap-3 items-start mb-4">
                  <div className="w-12 h-12 bg-cream-dark rounded-xl flex items-center justify-center text-2xl shrink-0">{b.emoji}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-1">
                      <div className="text-[15px] font-extrabold truncate">{b.name}</div>
                      {b.verified && <span className="text-green-500 text-sm shrink-0">✅</span>}
                    </div>
                    <div className="text-xs text-ink/40 mb-2 truncate">{b.tags.slice(0, 3).join(" · ")}</div>
                    <span className={`badge text-[9px] ${b.open ? "bg-green-50 text-green-700" : "bg-red-50 text-red-600"}`}>{b.open ? "● Open Now" : "● Closed"}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between border-t border-black/5 pt-3">
                  <div>
                    <div className="flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 fill-gold text-gold" />
                      <span className="text-sm font-extrabold">{b.rating}</span>
                      <span className="text-xs text-ink/40">({b.reviews})</span>
                    </div>
                    <div className="text-[10px] text-ink/30 mt-0.5">{b.location}</div>
                  </div>
                  <span className="text-xs font-bold text-ink/40 border border-black/8 px-2 py-1 rounded-lg">View →</span>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 text-ink/30">
            <div className="text-5xl mb-4">🏪</div>
            <div className="text-lg font-bold mb-2">No businesses found</div>
            <div className="text-sm">Be the first to list a business in {currentState?.name}!</div>
          </div>
        )}
      </div>
    </div>
  );
}
