"use client";
import { useState } from "react";
import Link from "next/link";
import { BUSINESSES } from "@/lib/data";
import { ArrowLeft, Star, Phone, Globe, MapPin, Clock } from "lucide-react";

const REVIEWS = [
  { author: "Deepa R.", stars: 5, date: "2 weeks ago", text: "Absolutely amazing! Best in the area, hands down. Highly recommend to anyone looking for an authentic experience." },
  { author: "Suresh M.", stars: 4, date: "1 month ago", text: "Great quality, slightly slow on busy nights. But totally worth it. Will be back soon!" },
  { author: "Priya K.", stars: 5, date: "3 weeks ago", text: "Took my parents here when they visited from India. They were impressed! That says everything." },
];

export default function BizDetailPage({ params }) {
  const biz = BUSINESSES.find((b) => b.id === params.id);
  const [tab, setTab] = useState("overview");
  const [newRating, setNewRating] = useState(0);
  const [reviewText, setReviewText] = useState("");
  const [submitted, setSubmitted] = useState(false);

  if (!biz) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center"><div className="text-4xl mb-4">🏪</div><div className="font-bold">Business not found</div><Link href="/directory" className="btn-fill mt-4 inline-flex">Back to Directory</Link></div>
    </div>
  );

  return (
    <div className="min-h-screen pt-16">
      <div className="h-48 bg-gradient-to-br from-cream-dark to-cream flex items-center justify-center text-7xl">{biz.emoji}</div>
      <div className="max-w-5xl mx-auto px-6 pb-16">
        <Link href="/directory" className="inline-flex items-center gap-2 text-sm text-ink/50 hover:text-ink mt-4 mb-6 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Directory
        </Link>

        <div className="grid lg:grid-cols-[1fr_300px] gap-10 items-start">
          <div>
            <div className="flex gap-2 mb-3 flex-wrap">
              <span className="badge bg-black/5 text-ink/60">{biz.category}</span>
              {biz.verified && <span className="badge bg-green-50 text-green-700">✅ Verified Business</span>}
              <span className={`badge ${biz.open ? "bg-green-50 text-green-700" : "bg-red-50 text-red-600"}`}>{biz.open ? "● Open Now" : "● Closed"}</span>
            </div>
            <h1 className="font-serif text-3xl md:text-4xl font-black tracking-tight mb-3">{biz.name}</h1>
            <div className="flex items-center gap-3 mb-8 flex-wrap">
              <div className="flex items-center gap-1"><Star className="w-5 h-5 fill-gold text-gold" /><span className="text-lg font-black">{biz.rating}</span></div>
              <span className="text-ink/40">{biz.reviews} reviews</span>
              <span className="text-ink/40">·</span><span className="text-ink/40">{biz.location}</span>
              <span className="text-ink/40">·</span><span className="font-bold">{biz.priceRange}</span>
            </div>

            <div className="flex gap-2 mb-8">
              {["overview", "reviews", "photos"].map((t) => (
                <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 rounded-lg text-sm font-bold border transition-all capitalize ${tab === t ? "bg-ink text-cream border-ink" : "border-black/10 text-ink/60 hover:border-black/30"}`}>{t}</button>
              ))}
            </div>

            {tab === "overview" && (
              <>
                <h2 className="text-xl font-extrabold mb-3">About</h2>
                <p className="text-ink/60 leading-relaxed mb-8">{biz.description}</p>
                <div className="grid sm:grid-cols-2 gap-4">
                  {[[MapPin, "Address", biz.address], [Clock, "Hours", biz.hours], [Phone, "Phone", biz.phone], [Globe, "Price Range", biz.priceRange]].map(([Icon, label, val]) => (
                    <div key={label} className="card p-4">
                      <Icon className="w-4 h-4 text-saffron mb-2" />
                      <div className="label">{label}</div>
                      <div className="text-sm font-bold">{val}</div>
                    </div>
                  ))}
                </div>
              </>
            )}

            {tab === "reviews" && (
              <div className="space-y-4">
                {REVIEWS.map((r, i) => (
                  <div key={i} className="card p-5">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex gap-3 items-center">
                        <div className="w-9 h-9 bg-saffron/10 rounded-xl flex items-center justify-center font-bold text-saffron">{r.author[0]}</div>
                        <div><div className="text-sm font-bold">{r.author}</div><div className="text-xs text-ink/40">{r.date}</div></div>
                      </div>
                      <div className="flex gap-0.5">{[...Array(r.stars)].map((_, i) => <Star key={i} className="w-4 h-4 fill-gold text-gold" />)}</div>
                    </div>
                    <p className="text-sm text-ink/60 leading-relaxed">{r.text}</p>
                  </div>
                ))}
                <div className="card p-5">
                  <h4 className="font-extrabold mb-4">Write a Review</h4>
                  <div className="flex gap-2 mb-4">
                    {[1,2,3,4,5].map((s) => (
                      <button key={s} onClick={() => setNewRating(s)}>
                        <Star className={`w-7 h-7 transition-all ${s <= newRating ? "fill-gold text-gold" : "text-black/15"}`} />
                      </button>
                    ))}
                  </div>
                  <textarea value={reviewText} onChange={(e) => setReviewText(e.target.value)} rows={3} placeholder="Share your experience..." className="input resize-none mb-3" />
                  <button onClick={() => setSubmitted(true)} className="btn-fill">
                    {submitted ? "✓ Review Posted!" : "Post Review"}
                  </button>
                </div>
              </div>
            )}

            {tab === "photos" && (
              <div className="grid grid-cols-3 gap-3">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="aspect-square bg-cream-dark rounded-xl flex items-center justify-center text-4xl border border-black/5">{biz.emoji}</div>
                ))}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="sticky top-20 space-y-4">
            <div className="card p-5 shadow-lg">
              <button className="btn-fill w-full justify-center mb-3">📞 Call Now</button>
              <button className="btn-outline w-full justify-center mb-3">🗓️ Book Appointment</button>
              {biz.website && <a href={biz.website} target="_blank" rel="noopener noreferrer" className="btn-outline w-full justify-center block text-center">🌐 Website</a>}
            </div>
            <div className="card p-5">
              <div className="font-extrabold text-sm mb-4">Rating Breakdown</div>
              {[5,4,3,2,1].map((s) => {
                const pct = [75,15,6,3,1][5-s];
                return (
                  <div key={s} className="flex items-center gap-2 mb-2">
                    <span className="text-xs text-ink/40 w-3">{s}</span>
                    <Star className="w-3 h-3 fill-gold text-gold" />
                    <div className="flex-1 h-2 bg-black/5 rounded-full overflow-hidden"><div className="h-full bg-gold rounded-full" style={{ width: `${pct}%` }} /></div>
                    <span className="text-[10px] font-mono text-ink/30 w-7">{pct}%</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
