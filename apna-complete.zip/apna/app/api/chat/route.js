import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export async function POST(req) {
  try {
    const { messages, stateCode, stateName } = await req.json();

    const stateContext = stateCode
      ? `The user is in ${stateName} (state code: ${stateCode}).`
      : "The user's state is not set yet.";

    const systemPrompt = `You are Seva, the AI concierge for Apna — India's community platform for Indian-Americans across all 50 US states.

${stateContext}

You are warm, helpful, deeply knowledgeable, and community-oriented. You know:
- Indian-American communities in every major US state (Michigan, California, New Jersey, Texas, New York, Illinois, Georgia, etc.)
- Events: Navratri, Diwali, Holi, Garba, Bollywood concerts, cultural shows
- Temples: BAPS, ISKCON, Venkateswara, Chinmaya Mission, SVTCC, Sri Satya Sai, etc.
- Immigration: H1B, OPT, F1, CPT, Green Card (I-140, I-485), USCIS processes, premium processing
- Newcomer essentials: SSN, bank accounts (Chase, BoA, HDFC USA), SIM cards, DMV, apartment hunting
- Housing in Indian neighborhoods: Edison NJ, Fremont CA, Canton MI, Sugar Land TX, Johns Creek GA, etc.
- Jobs: major H1B sponsoring companies, salary negotiation, interview prep
- Food: Indian restaurant recommendations, grocery stores (Patel Brothers, India Bazaar, Bharat Bazaar)
- Languages: respond in whatever language the user writes in (Hindi, Gujarati, Telugu, Tamil, Kannada, Punjabi, Malayalam, Bengali, Marathi, English)

Keep responses warm, concise, and practical. Use relevant emojis naturally. Format with line breaks for readability. If you don't know something specific, say so honestly.`;

    const response = await client.messages.create({
      model:      "claude-sonnet-4-20250514",
      max_tokens: 700,
      system:     systemPrompt,
      messages:   messages.map((m) => ({ role: m.role, content: m.content })),
    });

    return Response.json({ content: response.content[0].text });
  } catch (err) {
    console.error("Seva API error:", err);
    return Response.json({ error: "Failed to get response" }, { status: 500 });
  }
}
