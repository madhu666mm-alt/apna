"use client";
import Link from "next/link";
import { useAppState } from "@/context/StateContext";
import { EVENTS, BUSINESSES, JOBS, byState } from "@/lib/data";
import { MapPin, ArrowRight, Star } from "lucide-react";

function StatBadge({ num, label }) {
  return (
    <div>
      <div className="font-serif text-3xl font-black leading-none">{num}</div>
      <div className="text-xs font-semibold text-ink/40 mt-1 tracking-wide">{label}</div>
    </div>
  );
}

function EventCard({ event }) {
  return (
    <Link href={`/events/${event.id}`} className="card card-hover block overflow-hidden">
      <div className="h-1.5" style={{ background: `linear-gradient(90deg,${event.color},${event.color}88)` }} />
      <div className="p-5">
        <div className="flex gap-3 items-start mb-3">
          <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0" style={{ background: `${event.color}15` }}>
            {event.emoji}
          </div>
          <div>
            <div className="text-[10px] font-mono font-bold uppercase tracking-widest mb-1" style={{ color: event.color }}>{event.category}</div>
            <div className="text-[15px] font-extrabold leading-tight text-ink">{event.title}</div>
            <div className="text-xs text-ink/50 mt-0.5">{event.city} · {event.date}</div>
          </div>
        </div>
        <div className="flex items-center justify-between pt-3 border-t border-black/5">
          <span className="text-base font-black">{event.price === 0 ? "Free" : `$${event.price}`}</span>
          <span className="text-xs font-bold text-white px-3 py-1.5 rounded-lg" style={{ background: event.color }}>
            {event.price === 0 ? "RSVP" : "Tickets"} →
          </span>
        </div>
      </div>
    </Link>
  );
}

function BizCard({ biz }) {
  return (
    <Link href={`/directory/${biz.id}`} className="card card-hover block p-4">
      <div className="flex gap-3 items-start mb-3">
        <div className="w-11 h-11 rounded-xl bg-cream-dark flex items-center justify-center text-xl shrink-0">{biz.emoji}</div>
        <div className="flex-1 min-w-0">
          <div className="text-[14px] font-extrabold truncate">{biz.name}</div>
          <div className="text-[11px] text-ink/40 truncate">{biz.tags.slice(0, 2).join(" · ")}</div>
        </div>
        <div className={`badge text-[9px] ${biz.open ? "bg-green-50 text-green-700" : "bg-red-50 text-red-600"}`}>
          {biz.open ? "Open" : "Closed"}
        </div>
      </div>
      <div className="flex items-center gap-1.5">
        <Star className="w-3.5 h-3.5 fill-gold text-gold" />
        <span className="text-sm font-bold">{biz.rating}</span>
        <span className="text-xs text-ink/40">({biz.reviews} reviews)</span>
        <span className="text-xs text-ink/30 ml-auto">{biz.location}</span>
      </div>
    </Link>
  );
}

export default function HomePage() {
  const { currentState, stateCode, changeState } = useAppState();

  const events     = byState(EVENTS, stateCode).slice(0, 4);
  const businesses = byState(BUSINESSES, stateCode).slice(0, 6);
  const jobs       = byState(JOBS, stateCode).slice(0, 4);

  return (
    <div>
      {/* ── HERO ── */}
      <section className="min-h-screen flex items-center pt-24 pb-16 px-6 relative overflow-hidden bg-gradient-to-br from-cream via-cream-dark to-cream">
        <div className="pointer-events-none absolute top-0 right-0 w-[600px] h-[600px] rounded-full bg-saffron/8 blur-[120px]" />
        <div className="pointer-events-none absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full bg-gold/8 blur-[100px]" />

        <div className="max-w-screen-xl mx-auto w-full grid lg:grid-cols-2 gap-16 items-center relative z-10">
          {/* LEFT */}
          <div>
            {currentState && (
              <button onClick={changeState} className="inline-flex items-center gap-2 bg-saffron/10 border border-saffron/25 rounded-full px-4 py-2 text-xs font-bold text-saffron mb-6 hover:bg-saffron/15 transition-all">
                <div className="w-1.5 h-1.5 rounded-full bg-saffron animate-pulse-dot" />
                {currentState.name} · {currentState.cities.slice(0,3).join(", ")}
                <span className="opacity-50">Change →</span>
              </button>
            )}

            <h1 className="font-serif text-5xl md:text-6xl lg:text-7xl font-black leading-[0.95] tracking-tight mb-6">
              <span className="text-saffron italic">आपना</span>{" "}
              {currentState ? currentState.name : "America"}.<br />
              Your community,<br />your home.
            </h1>

            <p className="text-lg text-ink/50 leading-relaxed mb-8 max-w-lg">
              Events, businesses, jobs, accommodation, roommates, AI assistant — everything the Indian-American family needs, all in one place. Free, forever.
            </p>

            <div className="flex flex-wrap gap-3 mb-10">
              {[
                ["🎟️", "Events",         "/events"],
                ["🏪", "Directory",      "/directory"],
                ["💼", "Jobs",           "/jobs"],
                ["🏠", "Accommodation",  "/accommodations"],
                ["🤝", "Roommates",      "/roommates"],
                ["🛬", "Newcomers",      "/newcomers"],
              ].map(([emoji, label, href]) => (
                <Link key={href} href={href} className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-black/8 bg-white font-bold text-sm hover:border-saffron/30 hover:bg-saffron/5 transition-all">
                  {emoji} {label}
                </Link>
              ))}
            </div>

            <div className="flex gap-8 flex-wrap">
              <StatBadge num="50" label="States Covered" />
              <StatBadge num="600+" label="Events / Year" />
              <StatBadge num="400+" label="Businesses" />
              <StatBadge num="H1B" label="Job Filters" />
            </div>
          </div>

          {/* RIGHT — floating preview cards */}
          <div className="hidden lg:flex flex-col gap-4">
            {/* Event preview */}
            <div className="card p-5 rotate-[1.5deg] shadow-xl">
              <div className="flex gap-3 items-center mb-3">
                <div className="w-11 h-11 bg-gradient-to-br from-saffron to-gold rounded-xl flex items-center justify-center text-xl">🪔</div>
                <div>
                  <div className="text-[10px] font-mono font-bold text-saffron uppercase tracking-widest mb-0.5">Festival · Oct 2</div>
                  <div className="text-[15px] font-extrabold">Navratri Mahotsav 2026</div>
                  <div className="text-xs text-ink/40">Novi Civic Center · 7:00 PM</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1.5 bg-black/5 rounded-full overflow-hidden"><div className="w-[64%] h-full bg-gradient-to-r from-saffron to-gold rounded-full" /></div>
                <span className="text-[11px] font-mono text-ink/40">320/500</span>
                <span className="text-xs font-bold text-white bg-saffron px-3 py-1 rounded-lg">Get Tickets</span>
              </div>
            </div>

            {/* Biz preview */}
            <div className="card p-4 -rotate-[0.8deg] shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex gap-3 items-center">
                  <div className="w-10 h-10 bg-cream-dark rounded-xl flex items-center justify-center text-xl">🍛</div>
                  <div>
                    <div className="text-[14px] font-extrabold">Annapurna Indian Kitchen</div>
                    <div className="flex items-center gap-1 mt-0.5">
                      <Star className="w-3 h-3 fill-gold text-gold" /><span className="text-sm font-bold">4.8</span><span className="text-xs text-ink/40">(312 reviews)</span>
                    </div>
                  </div>
                </div>
                <span className="badge bg-green-50 text-green-700">Open</span>
              </div>
            </div>

            {/* Roommate preview */}
            <div className="card p-4 rotate-[0.5deg] shadow-xl">
              <div className="flex gap-3 items-start">
                <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-xl">🤝</div>
                <div>
                  <div className="text-[10px] font-mono font-bold text-blue-600 uppercase tracking-widest mb-0.5">Roommate Wanted</div>
                  <div className="text-[14px] font-extrabold">Male · Troy / Novi / Canton</div>
                  <div className="text-xs text-ink/40">Budget: $900/mo · Vegetarian · Non-smoker</div>
                </div>
              </div>
            </div>

            {/* AI preview */}
            <div className="bg-ink rounded-2xl p-4 rotate-[0.3deg] shadow-xl">
              <div className="flex gap-3 items-start">
                <div className="w-9 h-9 bg-gradient-to-br from-saffron to-gold rounded-xl flex items-center justify-center text-base shrink-0">🙏</div>
                <div>
                  <div className="text-[10px] font-mono font-bold text-gold uppercase tracking-widest mb-1">Seva AI · Live</div>
                  <div className="text-[13px] text-cream/70 leading-relaxed">Navratri is at BAPS this year. Want the schedule? I can also help in Hindi or Gujarati 🙂</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── EVENTS ── */}
      <section className="py-20 px-6 bg-cream">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-end justify-between mb-10 flex-wrap gap-4">
            <div>
              <div className="section-tag">// Events</div>
              <h2 className="section-title mb-0">
                Upcoming in{" "}
                <span className="text-saffron">{currentState?.name || "Your State"}</span>
              </h2>
            </div>
            <Link href="/events" className="btn-outline">
              All Events <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          {events.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {events.map((e) => <EventCard key={e.id} event={e} />)}
            </div>
          ) : (
            <div className="text-center py-16 text-ink/30">
              <div className="text-4xl mb-4">📅</div>
              <div className="font-semibold">No events listed for {currentState?.name} yet.</div>
              <div className="text-sm mt-2">Be the first to post an event!</div>
            </div>
          )}
        </div>
      </section>

      {/* ── DIRECTORY ── */}
      <section className="py-20 px-6 bg-cream-dark">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-end justify-between mb-10 flex-wrap gap-4">
            <div>
              <div className="section-tag">// Directory</div>
              <h2 className="section-title mb-0">Indian Businesses Near You</h2>
            </div>
            <Link href="/directory" className="btn-outline">
              Full Directory <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          {businesses.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {businesses.map((b) => <BizCard key={b.id} biz={b} />)}
            </div>
          ) : (
            <div className="text-center py-16 text-ink/30">
              <div className="text-4xl mb-4">🏪</div>
              <div className="font-semibold">No businesses listed for {currentState?.name} yet.</div>
              <Link href="/dashboard" className="btn-fill mt-4 inline-flex">List Your Business</Link>
            </div>
          )}
        </div>
      </section>

      {/* ── JOBS ── */}
      <section className="py-20 px-6 bg-cream">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-end justify-between mb-10 flex-wrap gap-4">
            <div>
              <div className="section-tag">// Jobs</div>
              <h2 className="section-title mb-0">Jobs with <span className="text-green-600">Visa Filters</span></h2>
            </div>
            <Link href="/jobs" className="btn-outline">All Jobs <ArrowRight className="w-4 h-4" /></Link>
          </div>
          <div className="flex flex-col gap-3">
            {jobs.map((j) => (
              <div key={j.id} className="card card-hover p-5 flex flex-wrap items-center gap-4 justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-cream-dark rounded-xl flex items-center justify-center text-2xl shrink-0">{j.emoji}</div>
                  <div>
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className="text-[15px] font-extrabold">{j.title}</span>
                      {j.hot && <span className="badge bg-red-50 text-red-600">🔥 Hot</span>}
                    </div>
                    <div className="text-sm text-ink/50 mb-2">{j.company} · {j.location}</div>
                    <div className="flex gap-2 flex-wrap">
                      <span className="badge bg-green-50 text-green-700">{j.visa}</span>
                      <span className="badge bg-black/5 text-ink/60">{j.type}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-base font-black mb-2">{j.salary}</div>
                  <Link href="/jobs" className="btn-fill text-xs px-4 py-2">Apply →</Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── HOUSING & ROOMMATES ── */}
      <section className="py-20 px-6 bg-ink text-cream">
        <div className="max-w-screen-xl mx-auto">
          <div className="section-tag text-gold/70">// Housing</div>
          <h2 className="section-title text-cream mb-4">Find Your Place in {currentState?.name || "Your State"}</h2>
          <p className="text-cream/40 text-base leading-relaxed mb-12 max-w-xl">Community-verified accommodations and roommate listings. Find a place with people who understand your lifestyle.</p>
          <div className="grid md:grid-cols-2 gap-6">
            <Link href="/accommodations" className="block p-8 rounded-2xl border border-white/8 bg-white/5 hover:bg-white/8 hover:border-saffron/30 transition-all group">
              <div className="text-4xl mb-5">🏠</div>
              <div className="text-xl font-extrabold mb-2">Find Accommodation</div>
              <div className="text-cream/40 text-sm leading-relaxed mb-6">Apartments, houses, studios, rooms — verified listings in Indian neighborhoods near temples, groceries, and tech corridors.</div>
              <span className="text-saffron font-bold text-sm group-hover:gap-3 flex items-center gap-2 transition-all">Browse Listings <ArrowRight className="w-4 h-4" /></span>
            </Link>
            <Link href="/roommates" className="block p-8 rounded-2xl border border-white/8 bg-white/5 hover:bg-white/8 hover:border-gold/30 transition-all group">
              <div className="text-4xl mb-5">🤝</div>
              <div className="text-xl font-extrabold mb-2">Find a Roommate</div>
              <div className="text-cream/40 text-sm leading-relaxed mb-6">Indian professionals and students looking for roommates. Filter by diet, habits, gender, budget, and city. Meet your next roomie safely.</div>
              <span className="text-gold font-bold text-sm flex items-center gap-2 group-hover:gap-3 transition-all">Browse Profiles <ArrowRight className="w-4 h-4" /></span>
            </Link>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-20 px-6 bg-gradient-to-br from-saffron to-gold text-center">
        <h2 className="font-serif text-4xl md:text-5xl font-black text-white mb-4 leading-tight">
          Your community is waiting.
        </h2>
        <p className="text-white/75 text-lg max-w-lg mx-auto mb-10 leading-relaxed">
          Join thousands of Indian-Americans who found their events, businesses, jobs, and homes on Apna. Free, forever.
        </p>
        <div className="flex gap-4 justify-center flex-wrap">
          <button className="px-8 py-4 rounded-xl bg-white text-saffron font-extrabold text-base hover:bg-white/90 transition-all">Join Apna Free →</button>
          <Link href="/directory" className="px-8 py-4 rounded-xl border-2 border-white/50 text-white font-extrabold text-base hover:bg-white/10 transition-all">List Your Business</Link>
        </div>
      </section>
    </div>
  );
}
