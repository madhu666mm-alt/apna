"use client";
import { useState } from "react";
import { TrendingUp, Star, Eye, MessageSquare, DollarSign, BarChart2 } from "lucide-react";

const TABS = ["Overview", "Reviews", "Analytics", "Promotions"];
const STATS = [
  { label: "Profile Views", value: "2,847", change: "+18%", icon: Eye,           color: "#2563EB" },
  { label: "Avg Rating",    value: "4.8",   change: "+0.2", icon: Star,          color: "#F5A623" },
  { label: "Total Reviews", value: "312",   change: "+24",  icon: MessageSquare, color: "#059669" },
  { label: "Monthly Leads", value: "47",    change: "+12%", icon: TrendingUp,    color: "#E8420A" },
];
const RECENT_REVIEWS = [
  { author: "Rajan M.", stars: 5, text: "Best in Michigan! My whole family loves it.", date: "2 days ago" },
  { author: "Sunita K.", stars: 4, text: "Great food, a bit slow on weekends. Will definitely return.", date: "1 week ago" },
  { author: "Priya T.", stars: 5, text: "Authentic taste, reminded me of home. Highly recommended!", date: "2 weeks ago" },
];
const CHART_DATA = [42, 65, 58, 78, 91, 103, 88, 120, 135, 118, 142, 157];
const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

export default function DashboardPage() {
  const [tab, setTab] = useState("Overview");

  return (
    <div className="min-h-screen pt-16 bg-cream">
      <div className="bg-ink px-6 pt-10 pb-8">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="text-[10px] font-mono font-bold uppercase tracking-widest text-gold/70 mb-2">Business Dashboard</div>
              <h1 className="font-serif text-3xl font-black text-cream">Annapurna Indian Kitchen</h1>
              <div className="flex items-center gap-2 mt-2">
                <span className="badge bg-green-500/20 text-green-400">✅ Verified</span>
                <span className="badge bg-gold/15 text-gold">⭐ Premium Listing</span>
              </div>
            </div>
            <div className="flex gap-3">
              <button className="btn-outline border-white/15 text-cream/60 hover:bg-white/8">Edit Profile</button>
              <button className="btn-fill">Upgrade Plan →</button>
            </div>
          </div>

          <div className="flex gap-1 mt-8">
            {TABS.map((t) => (
              <button key={t} onClick={() => setTab(t)} className={`px-4 py-2.5 rounded-t-xl text-sm font-bold transition-all ${tab === t ? "bg-cream text-ink" : "text-cream/40 hover:text-cream/60"}`}>{t}</button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-6 py-8">
        {tab === "Overview" && (
          <div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {STATS.map(({ label, value, change, icon: Icon, color }) => (
                <div key={label} className="card p-5">
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${color}15` }}>
                      <Icon className="w-5 h-5" style={{ color }} />
                    </div>
                    <span className="text-[11px] font-mono font-bold text-green-600 bg-green-50 px-2 py-1 rounded-lg">{change}</span>
                  </div>
                  <div className="text-2xl font-black mb-1">{value}</div>
                  <div className="text-xs text-ink/40 font-semibold">{label}</div>
                </div>
              ))}
            </div>

            <div className="grid lg:grid-cols-[1fr_340px] gap-6">
              <div className="card p-6">
                <h3 className="font-extrabold mb-6 flex items-center gap-2"><BarChart2 className="w-5 h-5 text-saffron" /> Profile Views — Last 12 Months</h3>
                <div className="flex items-end gap-2 h-40">
                  {CHART_DATA.map((v, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <div className="w-full rounded-t-lg transition-all hover:opacity-90" style={{ height: `${(v / 160) * 100}%`, background: `linear-gradient(180deg, #E8420A, #F5A623)` }} />
                      <span className="text-[9px] font-mono text-ink/30">{MONTHS[i]}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card p-6">
                <h3 className="font-extrabold mb-5">Recent Reviews</h3>
                <div className="space-y-4">
                  {RECENT_REVIEWS.map((r, i) => (
                    <div key={i} className="pb-4 border-b border-black/5 last:border-0 last:pb-0">
                      <div className="flex justify-between items-start mb-1">
                        <span className="text-sm font-bold">{r.author}</span>
                        <span className="text-[10px] text-ink/30 font-mono">{r.date}</span>
                      </div>
                      <div className="flex gap-0.5 mb-1.5">{[...Array(r.stars)].map((_, j) => <Star key={j} className="w-3 h-3 fill-gold text-gold" />)}</div>
                      <p className="text-xs text-ink/50 leading-relaxed">{r.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {tab === "Promotions" && (
          <div>
            <h2 className="text-xl font-extrabold mb-6">Promotion Plans</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                { name: "Starter", price: 0, features: ["Basic directory listing", "Up to 5 photos", "Customer reviews", "Standard search ranking"] },
                { name: "Premium", price: 49, features: ["Featured in search results", "Up to 30 photos", "Verified badge", "Priority support", "Monthly insights report", "Event listings included"], hot: true },
                { name: "Business Pro", price: 149, features: ["Homepage featured placement", "Unlimited photos + video", "Custom page URL", "Ad credits ($50/mo)", "Dedicated account manager", "Full analytics dashboard"] },
              ].map((plan) => (
                <div key={plan.name} className={`card p-6 ${plan.hot ? "border-saffron/30 shadow-xl relative overflow-hidden" : ""}`}>
                  {plan.hot && <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-saffron to-gold" />}
                  {plan.hot && <div className="badge bg-saffron text-white mb-4">Most Popular</div>}
                  <div className="font-serif text-xl font-black mb-1">{plan.name}</div>
                  <div className="text-3xl font-black mb-1">{plan.price === 0 ? "Free" : `$${plan.price}`}<span className="text-sm font-normal text-ink/40">{plan.price > 0 ? "/mo" : ""}</span></div>
                  <ul className="space-y-2 mb-6 mt-4">
                    {plan.features.map((f) => (
                      <li key={f} className="flex items-start gap-2 text-sm text-ink/70">
                        <span className="text-green-500 mt-0.5 shrink-0">✓</span>{f}
                      </li>
                    ))}
                  </ul>
                  <button className={plan.hot ? "btn-fill w-full justify-center" : "btn-outline w-full justify-center"}>
                    {plan.price === 0 ? "Current Plan" : "Upgrade →"}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "Analytics" && (
          <div className="text-center py-20 text-ink/30">
            <div className="text-5xl mb-4">📊</div>
            <div className="text-lg font-bold mb-2">Analytics — Premium Feature</div>
            <div className="text-sm mb-6">Get detailed click-through rates, phone call tracking, and audience insights.</div>
            <button onClick={() => setTab("Promotions")} className="btn-fill inline-flex">Upgrade to Premium →</button>
          </div>
        )}

        {tab === "Reviews" && (
          <div className="space-y-4 max-w-2xl">
            {[...RECENT_REVIEWS, ...RECENT_REVIEWS].map((r, i) => (
              <div key={i} className="card p-5">
                <div className="flex justify-between items-start mb-2">
                  <span className="font-bold">{r.author}</span>
                  <div className="flex gap-1">{[...Array(r.stars)].map((_, j) => <Star key={j} className="w-4 h-4 fill-gold text-gold" />)}</div>
                </div>
                <p className="text-sm text-ink/60 leading-relaxed mb-3">{r.text}</p>
                <div className="flex gap-2">
                  <button className="text-xs px-3 py-1.5 rounded-lg border border-black/10 font-semibold hover:bg-black/5">Reply</button>
                  <button className="text-xs px-3 py-1.5 rounded-lg border border-black/10 font-semibold text-ink/40 hover:bg-black/5">Report</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
